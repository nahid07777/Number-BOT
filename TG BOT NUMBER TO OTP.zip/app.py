#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===========================================================================
⚡ EHR QUICK INCOME - COMPLETE TELEGRAM OTP & NUMBER PANEL BOT (A-Z) ⚡
===========================================================================
Features Included (100% Matched to Video):
1. Native Telegram Bot API v7.11+ `copy_text` & `style` (Colored Buttons:
   Green='success', Red='danger', Blue='primary') + Zero-Dependency Standard
   Library Fallback (`urllib.request` + `http.server` + `sqlite3`) OR `aiohttp`
   if installed — runs out-of-the-box on any Python 3.8+ setup!
2. User Panel:
   - /start with Welcome Card, Optional Welcome Banner Image & Referral Tracking (?start=USER_ID)
   - Colored Bottom ReplyKeyboardMarkup:
     [🟢 ➕ GET NUMBER] [🔴 📅 BALANCE]
     [🔴 👥 REF. SYSTEM] [🔵 🧑‍💻 SUPPORT]
   - GET NUMBER -> Dynamic Service Selection -> Region/Country Selection ->
     Number Allocation Panel (1 or 2 numbers per session, Tap to Copy with
     native clipboard icon, Toggle With/Without Country Code, Change Number
     with 5-second Anti-Spam Cooldown Alert, Automatic Session Expiry handling,
     OTP Group Link, Close Button).
   - BALANCE (FINANCE & BILLING) -> Total OTPs, Total Refs, Current Balance (৳),
     Minimum Payout (100.0 ৳), Enable/Disable Withdrawals toggle by Admin,
     Interactive Withdrawal Request (Bkash, Nagad, Rocket, Binance) with
     Admin Approval/Rejection notification.
   - REF. SYSTEM (AFFILIATE PROGRAM) -> Unique Invite Link, Total Invites,
     Per-OTP Referral Commission (e.g. 0.1 TK), Native Copy Link button.
   - SUPPORT (HELP & SUPPORT) -> Direct Contact Support button.
3. OTP Group / Webhook Receiver & Simulator:
   - Built-in HTTP Webhook API (`POST /api/otp` or `GET /api/otp`) on port 8080
     to receive real SMS/OTPs from any Number Panel / GSM Gateway / IVASMS /
     SMS-Activate / Custom script!
   - Also supports Admin Live OTP Push (`/sendotp` or Admin Panel -> Fire Test OTP)
     which automatically detects the assigned user, credits their balance +
     referrer commission, notifies the user in DM, and posts the exact formatted
     OTP Card into the OTP Group with:
     [🛡️ 754891 (Copy)] [📩 Full SMS (Copy)]
     [⚪ Get Numbers (URL)] [📊 Channel (URL)]
4. Complete In-Bot Admin Panel (`/admin`) + Live Web Admin Panel (`http://localhost:8080/admin`):
   - View Dashboard Stats (Total Users, Total Numbers, Active Sessions, Total OTPs, Pending Withdrawals)
   - Add / Manage Services (Shopee, Twitter, Grab/Lalamove, Batery, All-App, Huawei, Uber, Twitter Forget, etc.)
   - Add / Manage Countries & Bulk Upload Numbers (Paste 1 or 10,000 numbers at once!)
   - Fire / Simulate Live OTP to any active or custom number (instantly posts to OTP Group & credits user!)
   - Toggle Withdrawals ON/OFF, Set Minimum Payout, Set Per-OTP Rate & Referral Commission
   - Manage & Approve/Reject Withdrawal Requests
   - Edit Bot Links (OTP Group URL, Main Channel URL, Support Username, Welcome Photo URL)
   - Broadcast Message to all users
===========================================================================
"""

import asyncio
import json
import logging
import os
import random
import re
import sqlite3
import time
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import threading

# ===========================================================================
# ⚙️ CONFIGURATION (এখানে আপনার BOT TOKEN এবং ADMIN USER ID বসান)
# ===========================================================================
BOT_TOKEN = os.getenv("BOT_TOKEN", "9235101132:AAEhe5J_uLiYtpc8ACsOereHD4ue3zn9PJU")
ADMIN_IDS = [
    int(x) for x in os.getenv("ADMIN_IDS", "9106283400").split(",") if x.strip().isdigit()
]

# ডিফল্ট গ্রুপ চ্যাট আইডি (OTP Group এ অটো মেসেজ পাঠানোর জন্য গ্রুপের Chat ID দিন, যেমন: -1001234567890)
# অথবা বটের /admin প্যানেল বা গ্রুপে /setotpgroup লিখেও সেট করতে পারবেন!
DEFAULT_OTP_GROUP_ID = os.getenv("OTP_GROUP_ID", "")

# ওয়েব অ্যাডমিন প্যানেল এবং OTP Webhook পোর্ট
WEB_PORT = int(os.getenv("WEB_PORT", "8080"))
DB_PATH = os.getenv("DB_PATH", "otp_bot_database.db")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("EHR_OTP_BOT")


# ===========================================================================
# 🗄️ DATABASE INITIALIZATION & HELPERS (SQLite3)
# ===========================================================================
def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=25.0)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = get_db()
    cur = conn.cursor()

    cur.execute("PRAGMA journal_mode = WAL")
    cur.execute("PRAGMA synchronous = NORMAL")
    cur.execute("PRAGMA cache_size = -64000")

    cur.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            balance REAL DEFAULT 0.0,
            total_otps INTEGER DEFAULT 0,
            referred_by INTEGER DEFAULT NULL,
            total_invites INTEGER DEFAULT 0,
            last_change_ts REAL DEFAULT 0.0,
            is_banned INTEGER DEFAULT 0,
            joined_at TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            icon TEXT DEFAULT '☑️',
            otp_rate REAL DEFAULT 2.0,
            numbers_per_click INTEGER DEFAULT 1,
            is_active INTEGER DEFAULT 1
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS countries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            service_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            flag TEXT NOT NULL,
            dial_code TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS numbers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            service_id INTEGER NOT NULL,
            country_id INTEGER NOT NULL,
            phone TEXT NOT NULL,
            assigned_to INTEGER DEFAULT NULL,
            session_msg_id INTEGER DEFAULT NULL,
            assigned_at REAL DEFAULT 0.0,
            status TEXT DEFAULT 'available'
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS number_sessions (
            session_id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            chat_id INTEGER NOT NULL,
            message_id INTEGER DEFAULT 0,
            service_id INTEGER NOT NULL,
            country_id INTEGER NOT NULL,
            numbers_json TEXT NOT NULL,
            show_country_code INTEGER DEFAULT 1,
            is_expired INTEGER DEFAULT 0,
            created_at REAL NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS otp_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT,
            service_name TEXT,
            country_flag TEXT,
            otp_code TEXT,
            full_sms TEXT,
            user_id INTEGER,
            reward REAL,
            created_at TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS withdrawals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            method TEXT NOT NULL,
            account_number TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS user_states (
            user_id INTEGER PRIMARY KEY,
            state TEXT,
            temp_data TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            user_id INTEGER PRIMARY KEY,
            role TEXT DEFAULT 'admin',
            added_by INTEGER DEFAULT NULL,
            added_at TEXT
        )
    """)
    for aid in ADMIN_IDS:
        cur.execute(
            "INSERT OR IGNORE INTO admins (user_id, role, added_at) VALUES (?, 'owner', ?)",
            (aid, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )

    # SQLite High-Performance Indexes
    cur.execute("CREATE INDEX IF NOT EXISTS idx_numbers_svc_cnt_status ON numbers (service_id, country_id, status)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_numbers_phone ON numbers (phone)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_users_tot_otps ON users (total_otps DESC)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_users_bal ON users (balance DESC)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user_active ON number_sessions (user_id, is_expired)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_countries_svc_active ON countries (service_id, is_active)")

    default_settings = {
        "bot_title": "EHR ⚡ QUICK INCOME OTP BOT",
        "bot_username": "numberotptest_bot",
        "welcome_photo": "",
        "min_payout": "100.0",
        "ref_commission": "0.1",
        "default_otp_rate": "2.5",
        "withdrawals_enabled": "0",  # 0 = disabled as shown in video ("Withdrawals are currently disabled by Admin."), 1 = enabled
        "change_cooldown": "5",
        "support_url": "https://t.me/EHR_SUPPORT",
        "otp_group_url": "https://t.me/QUICK_OTP_GROUP",
        "channel_url": "https://t.me/EHR_QUICK_INCOME",
        "otp_group_chat_id": str(DEFAULT_OTP_GROUP_ID),
        "payment_methods": "Bkash,Nagad,Rocket,Binance",
        "panel_api_url": "",
        "panel_api_token": "",
        "panel_api_enabled": "0",
        "panel_poll_interval": "8"
    }
    for k, v in default_settings.items():
        cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

    cur.execute("SELECT COUNT(*) as cnt FROM services")
    if cur.fetchone()["cnt"] == 0:
        seed_services = [
            ("SHOPEE", "🛍️", 2.5, 1),
            ("GRAB / LALAMOVE", "☑️", 3.0, 1),
            ("BATERY", "☑️", 2.0, 1),
            ("TWITTER", "✖️", 2.5, 2),
            ("ALL-APP", "☑️", 2.0, 1),
            ("HUAWEI", "☑️", 2.5, 1),
            ("UBER", "⬛", 3.0, 1),
            ("TWITTER FORGET", "✖️", 2.5, 2),
            ("FACEBOOK", "📘", 2.5, 1),
            ("INSTAGRAM", "📷", 2.5, 1),
            ("TIKTOK", "🎵", 2.5, 1),
        ]
        for s_name, s_icon, s_rate, s_num_cnt in seed_services:
            cur.execute(
                "INSERT INTO services (name, icon, otp_rate, numbers_per_click, is_active) VALUES (?, ?, ?, ?, 1)",
                (s_name, s_icon, s_rate, s_num_cnt)
            )
            s_id = cur.lastrowid

            if "SHOPEE" in s_name:
                countries_data = [
                    ("BELIZE", "🇧🇿", "+501", ["+5016709162", "+5016740258", "+5016239841", "+5016114590", "+5016883214"]),
                    ("CAMEROON", "🇨🇲", "+237", ["+237671234567", "+237679876543", "+237655443322"]),
                    ("UZBEKISTAN", "🇺🇿", "+998", ["+998931112233", "+998945556677", "+998909998877"]),
                    ("VIETNAM", "🇻🇳", "+84", ["+84912345678", "+84987654321", "+84905112233"]),
                ]
            elif "TWITTER" in s_name:
                countries_data = [
                    ("YEMEN", "🇾🇪", "+967", ["+967771234567", "+967779876543", "+967733445566", "+967711223344"]),
                    ("UZBEKISTAN", "🇺🇿", "+998", [
                        "+998939207321", "+998946917943", "+998936197825", "+998946812127",
                        "+998901234567", "+998919876543", "+998993871234", "+998998765432"
                    ]),
                    ("ANGOLA", "🇦🇴", "+244", ["+244923456893", "+244912345678", "+244934567890", "+244945678901"]),
                ]
            else:
                countries_data = [
                    ("UZBEKISTAN", "🇺🇿", "+998", ["+998931234567", "+998947654321", "+998971112233"]),
                    ("RUSSIA", "🇷🇺", "+7", ["+79811234401", "+79169876543", "+79261112233"]),
                    ("BELIZE", "🇧🇿", "+501", ["+5016655443", "+5016778899"]),
                ]

            for c_name, c_flag, c_code, sample_nums in countries_data:
                cur.execute(
                    "INSERT INTO countries (service_id, name, flag, dial_code, is_active) VALUES (?, ?, ?, ?, 1)",
                    (s_id, c_name, c_flag, c_code)
                )

    # Auto-seed default services (Facebook, Instagram, TikTok) if missing from pre-existing DBs
    for s_name, s_icon, s_rate, s_num in [("FACEBOOK", "📘", 2.5, 1), ("INSTAGRAM", "📷", 2.5, 1), ("TIKTOK", "🎵", 2.5, 1)]:
        chk = cur.execute("SELECT id FROM services WHERE name = ?", (s_name,)).fetchone()
        if not chk:
            cur.execute(
                "INSERT INTO services (name, icon, otp_rate, numbers_per_click, is_active) VALUES (?, ?, ?, ?, 1)",
                (s_name, s_icon, s_rate, s_num)
            )
            s_id = cur.lastrowid
            def_cnts = [
                ("UZBEKISTAN", "🇺🇿", "+998"),
                ("RUSSIA", "🇷🇺", "+7"),
                ("BELIZE", "🇧🇿", "+501"),
                ("VIETNAM", "🇻🇳", "+84"),
                ("ANGOLA", "🇦🇴", "+244")
            ]
            for c_name, c_flag, c_dial in def_cnts:
                cur.execute(
                    "INSERT INTO countries (service_id, name, flag, dial_code, is_active) VALUES (?, ?, ?, ?, 1)",
                    (s_id, c_name, c_flag, c_dial)
                )

    conn.commit()
    conn.close()


def get_all_services(active_only: bool = False) -> List[sqlite3.Row]:
    conn = get_db()
    if active_only:
        rows = conn.execute("SELECT * FROM services WHERE is_active = 1 ORDER BY id ASC").fetchall()
    else:
        rows = conn.execute("SELECT * FROM services ORDER BY id ASC").fetchall()
    conn.close()
    return rows


def get_service_by_id(service_id: int) -> Optional[sqlite3.Row]:
    conn = get_db()
    row = conn.execute("SELECT * FROM services WHERE id = ?", (service_id,)).fetchone()
    conn.close()
    return row


def get_service_by_name(name: str) -> Optional[sqlite3.Row]:
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM services WHERE UPPER(name) = UPPER(?) OR UPPER(name) LIKE UPPER(?)",
        (name.strip(), f"%{name.strip()}%")
    ).fetchone()
    conn.close()
    return row


def add_service(
    name: str,
    icon: str = "☑️",
    otp_rate: float = 2.5,
    numbers_per_click: int = 1,
    countries: Optional[List[Tuple[str, str, str, List[str]]]] = None
) -> int:
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO services (name, icon, otp_rate, numbers_per_click, is_active) VALUES (?, ?, ?, ?, 1)",
        (name.strip().upper(), (icon or "☑️").strip(), float(otp_rate), int(numbers_per_click))
    )
    s_id = cur.lastrowid

    seed_countries = countries or [
        ("UZBEKISTAN", "🇺🇿", "+998", ["+998931234567", "+998947654321"]),
        ("RUSSIA", "🇷🇺", "+7", ["+79811234401", "+79169876543"]),
        ("BELIZE", "🇧🇿", "+501", ["+5016655443", "+5016778899"]),
        ("VIETNAM", "🇻🇳", "+84", ["+84912345678", "+84987654321"]),
        ("ANGOLA", "🇦🇴", "+244", ["+244923456893", "+244912345678"]),
    ]
    for c_name, c_flag, c_dial, nums in seed_countries:
        cur.execute(
            "INSERT INTO countries (service_id, name, flag, dial_code, is_active) VALUES (?, ?, ?, ?, 1)",
            (s_id, c_name, c_flag, c_dial)
        )
        c_id = cur.lastrowid
        for p in nums:
            cur.execute(
                "INSERT INTO numbers (service_id, country_id, phone, status) VALUES (?, ?, ?, 'available')",
                (s_id, c_id, p)
            )
    conn.commit()
    conn.close()
    return s_id


def update_service_rate(service_id: int, new_rate: float) -> bool:
    conn = get_db()
    conn.execute("UPDATE services SET otp_rate = ? WHERE id = ?", (float(new_rate), service_id))
    conn.commit()
    conn.close()
    return True


def update_service_details(service_id: int, name: str, icon: str, otp_rate: float, numbers_per_click: int) -> bool:
    conn = get_db()
    conn.execute(
        "UPDATE services SET name = ?, icon = ?, otp_rate = ?, numbers_per_click = ? WHERE id = ?",
        (name.strip().upper(), icon.strip(), float(otp_rate), int(numbers_per_click), service_id)
    )
    conn.commit()
    conn.close()
    return True


def delete_service(service_id: int) -> bool:
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM numbers WHERE service_id = ?", (service_id,))
    cur.execute("DELETE FROM countries WHERE service_id = ?", (service_id,))
    cur.execute("DELETE FROM services WHERE id = ?", (service_id,))
    conn.commit()
    conn.close()
    return True


def toggle_service_active(service_id: int) -> int:
    conn = get_db()
    cur = conn.cursor()
    srv = cur.execute("SELECT is_active FROM services WHERE id = ?", (service_id,)).fetchone()
    new_st = 0 if (srv and srv["is_active"] == 1) else 1
    cur.execute("UPDATE services SET is_active = ? WHERE id = ?", (new_st, service_id))
    conn.commit()
    conn.close()
    return new_st


def get_setting(key: str, default: str = "") -> str:
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    conn = get_db()
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
    conn.commit()
    conn.close()


def get_float_setting(key: str, default: float = 100.0) -> float:
    raw = get_setting(key, str(default)).strip()
    try:
        return float(raw)
    except (ValueError, TypeError):
        return default


def get_or_create_user(user_dict: Dict[str, Any], referrer_id: Optional[int] = None) -> Tuple[sqlite3.Row, bool]:
    uid = user_dict["id"]
    username = user_dict.get("username") or ""
    first_name = user_dict.get("first_name") or "User"

    conn = get_db()
    cur = conn.cursor()
    row = cur.execute("SELECT * FROM users WHERE user_id = ?", (uid,)).fetchone()
    is_new = False

    if not row:
        is_new = True
        valid_ref = None
        if referrer_id and referrer_id != uid:
            ref_row = cur.execute("SELECT user_id FROM users WHERE user_id = ?", (referrer_id,)).fetchone()
            if ref_row:
                valid_ref = referrer_id
                cur.execute("UPDATE users SET total_invites = total_invites + 1 WHERE user_id = ?", (valid_ref,))

        cur.execute("""
            INSERT INTO users (user_id, username, first_name, referred_by, joined_at)
            VALUES (?, ?, ?, ?, ?)
        """, (uid, username, first_name, valid_ref, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        row = cur.execute("SELECT * FROM users WHERE user_id = ?", (uid,)).fetchone()
    else:
        cur.execute("UPDATE users SET username = ?, first_name = ? WHERE user_id = ?", (username, first_name, uid))
        conn.commit()

    conn.close()
    return row, is_new


def set_user_state(user_id: int, state: Optional[str], temp_data: Optional[Dict[str, Any]] = None) -> None:
    conn = get_db()
    if state is None:
        conn.execute("DELETE FROM user_states WHERE user_id = ?", (user_id,))
    else:
        conn.execute(
            "INSERT OR REPLACE INTO user_states (user_id, state, temp_data) VALUES (?, ?, ?)",
            (user_id, state, json.dumps(temp_data or {}))
        )
    conn.commit()
    conn.close()


def get_user_state(user_id: int) -> Tuple[Optional[str], Dict[str, Any]]:
    conn = get_db()
    row = conn.execute("SELECT state, temp_data FROM user_states WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()
    if not row:
        return None, {}
    try:
        data = json.loads(row["temp_data"] or "{}")
    except Exception:
        data = {}
    return row["state"], data


try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False


# ===========================================================================
# 🤖 DIRECT TELEGRAM BOT API ENGINE (SUPPORTS COLORED BUTTONS & COPY_TEXT)
# ===========================================================================
class TelegramAPI:
    def __init__(self, token: str):
        self.token = token
        self._session: Optional[Any] = None

    @property
    def base_url(self) -> str:
        tok = os.getenv("BOT_TOKEN", self.token)
        return f"https://api.telegram.org/bot{tok}"

    async def get_session(self) -> Any:
        if not HAS_AIOHTTP:
            return None
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(limit=100, keepalive_timeout=60, enable_cleanup_closed=True)
            timeout = aiohttp.ClientTimeout(total=45, connect=10)
            self._session = aiohttp.ClientSession(connector=connector, timeout=timeout)
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    def _sync_post(self, url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=35) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                err_body = e.read().decode("utf-8")
                return json.loads(err_body)
            except Exception:
                return {"ok": False, "description": str(e)}
        except Exception as e:
            return {"ok": False, "description": str(e)}

    async def call(self, method: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = f"{self.base_url}/{method}"
        p = payload or {}
        session = await self.get_session()
        if session:
            try:
                async with session.post(url, json=p) as resp:
                    data = await resp.json(content_type=None)
                    if not data.get("ok"):
                        desc = data.get("description", "")
                        if ("style" in desc or "copy_text" in desc) and "reply_markup" in p:
                            clean_payload = self._strip_advanced_button_fields(p)
                            async with session.post(url, json=clean_payload) as r2:
                                data = await r2.json(content_type=None)
                        elif method != "getUpdates":
                            logger.warning(f"Telegram API Warning [{method}]: {desc}")
                    return data
            except Exception as e:
                if method != "getUpdates":
                    logger.debug(f"aiohttp request failed for [{method}]: {e}")

        data = await asyncio.to_thread(self._sync_post, url, p)
        if not data.get("ok"):
            desc = data.get("description", "")
            if ("style" in desc or "copy_text" in desc) and "reply_markup" in p:
                clean_payload = self._strip_advanced_button_fields(p)
                data = await asyncio.to_thread(self._sync_post, url, clean_payload)
            elif method != "getUpdates":
                logger.warning(f"Telegram API Warning [{method}]: {desc}")
        return data

    def _strip_advanced_button_fields(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        p = json.loads(json.dumps(payload))
        rm = p.get("reply_markup", {})
        for key in ("inline_keyboard", "keyboard"):
            if key in rm:
                for row in rm[key]:
                    for btn in row:
                        btn.pop("style", None)
                        if "copy_text" in btn:
                            ct = btn.pop("copy_text")
                            btn["callback_data"] = f"fallback_copy:{ct.get('text', '')[:45]}"
        return p

    async def send_message(
        self,
        chat_id: Any,
        text: str,
        reply_markup: Optional[Dict[str, Any]] = None,
        parse_mode: str = "HTML",
        disable_web_page_preview: bool = True
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": disable_web_page_preview
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return await self.call("sendMessage", payload)

    async def edit_message_text(
        self,
        chat_id: Any,
        message_id: int,
        text: str,
        reply_markup: Optional[Dict[str, Any]] = None,
        parse_mode: str = "HTML",
        disable_web_page_preview: bool = True
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": disable_web_page_preview
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return await self.call("editMessageText", payload)

    async def delete_message(self, chat_id: Any, message_id: int) -> Dict[str, Any]:
        return await self.call("deleteMessage", {"chat_id": chat_id, "message_id": message_id})

    async def send_photo(
        self,
        chat_id: Any,
        photo: str,
        caption: Optional[str] = None,
        reply_markup: Optional[Dict[str, Any]] = None,
        parse_mode: str = "HTML"
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "chat_id": chat_id,
            "photo": photo,
            "parse_mode": parse_mode
        }
        if caption:
            payload["caption"] = caption
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return await self.call("sendPhoto", payload)

    async def set_my_description(self, description: str, language_code: str = "") -> Dict[str, Any]:
        payload: Dict[str, Any] = {"description": description}
        if language_code:
            payload["language_code"] = language_code
        return await self.call("setMyDescription", payload)

    async def set_my_short_description(self, short_description: str, language_code: str = "") -> Dict[str, Any]:
        payload: Dict[str, Any] = {"short_description": short_description}
        if language_code:
            payload["language_code"] = language_code
        return await self.call("setMyShortDescription", payload)

    async def set_my_commands(self, commands: List[Dict[str, str]], scope: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"commands": commands}
        if scope:
            payload["scope"] = scope
        return await self.call("setMyCommands", payload)

    async def set_chat_menu_button(self, chat_id: Optional[int] = None, menu_button: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        if chat_id:
            payload["chat_id"] = chat_id
        if menu_button:
            payload["menu_button"] = menu_button
        else:
            payload["menu_button"] = {"type": "commands"}
        return await self.call("setChatMenuButton", payload)

    def _sync_download_file(self, file_path: str) -> str:
        tok = os.getenv("BOT_TOKEN", self.token)
        url = f"https://api.telegram.org/file/bot{tok}/{file_path}"
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=35) as resp:
            return resp.read().decode("utf-8", errors="ignore")

    async def download_document_text(self, file_id: str) -> str:
        res = await self.call("getFile", {"file_id": file_id})
        if not res.get("ok"):
            return ""
        file_path = res["result"].get("file_path", "")
        if not file_path:
            return ""
        return await asyncio.to_thread(self._sync_download_file, file_path)

    async def answer_callback_query(
        self,
        callback_query_id: str,
        text: Optional[str] = None,
        show_alert: bool = False
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"callback_query_id": callback_query_id, "show_alert": show_alert}
        if text:
            payload["text"] = text
        return await self.call("answerCallbackQuery", payload)


bot = TelegramAPI(BOT_TOKEN)


# ===========================================================================
# 🎨 KEYBOARDS & UI BUILDERS (EXACT MATCH TO VIDEO)
# ===========================================================================
def main_reply_keyboard(is_admin: bool = False) -> Dict[str, Any]:
    """
    Bottom persistent keyboard with exact labels & colored styles:
    Row 1: [➕ GET NUMBER (Green)] [📅 BALANCE (Red)]
    Row 2: [🏆 LEADERBOARD (Blue)] [👥 REF. SYSTEM (Red)]
    Row 3: [🧑‍💻 SUPPORT (Blue)]
    Row 4 (Admin only): [⚙️ ADMIN PANEL]
    """
    kb = [
        [
            {"text": "➕ GET NUMBER", "style": "success"},
            {"text": "📅 BALANCE", "style": "danger"}
        ],
        [
            {"text": "🏆 LEADERBOARD", "style": "primary"},
            {"text": "👥 REF. SYSTEM", "style": "danger"}
        ],
        [
            {"text": "🧑‍💻 SUPPORT", "style": "primary"}
        ]
    ]
    if is_admin:
        kb.append([{"text": "⚙️ ADMIN PANEL", "style": "primary"}])
    return {
        "keyboard": kb,
        "resize_keyboard": True,
        "is_persistent": True
    }


def affiliate_keyboard(ref_link: str) -> Dict[str, Any]:
    return {
        "inline_keyboard": [
            [{"text": "🔗 COPY LINK", "copy_text": {"text": ref_link}, "style": "success"}],
            [
                {"text": "🏠 Main Menu", "callback_data": "menu:start", "style": "primary"},
                {"text": "❌ Close", "callback_data": "close_msg", "style": "danger"}
            ]
        ]
    }


def support_keyboard(support_url: str) -> Dict[str, Any]:
    return {
        "inline_keyboard": [
            [{"text": "👩‍💻 Contact Support", "url": support_url, "style": "success"}],
            [
                {"text": "🏠 Main Menu", "callback_data": "menu:start", "style": "primary"},
                {"text": "❌ Close", "callback_data": "close_msg", "style": "danger"}
            ]
        ]
    }


def leaderboard_keyboard() -> Dict[str, Any]:
    return {
        "inline_keyboard": [
            [
                {"text": "🔄 Refresh", "callback_data": "refresh_leaderboard", "style": "primary"},
                {"text": "➕ Get Number", "callback_data": "menu:getnumber", "style": "success"}
            ],
            [
                {"text": "🏠 Main Menu", "callback_data": "menu:start", "style": "primary"},
                {"text": "❌ Close", "callback_data": "close_msg", "style": "danger"}
            ]
        ]
    }


def balance_keyboard(withdrawals_enabled: bool, methods: List[str]) -> Dict[str, Any]:
    rows = []
    if not withdrawals_enabled:
        rows.append([{"text": "❌ Withdrawal Not Available", "callback_data": "withdraw_disabled", "style": "danger"}])
    else:
        method_row = []
        for m in methods:
            m_clean = m.strip()
            if not m_clean:
                continue
            method_row.append({"text": f"💸 {m_clean}", "callback_data": f"withdraw_method:{m_clean}", "style": "success"})
            if len(method_row) == 2:
                rows.append(method_row)
                method_row = []
        if method_row:
            rows.append(method_row)
    rows.append([
        {"text": "🏠 Main Menu", "callback_data": "menu:start", "style": "primary"},
        {"text": "❌ Close", "callback_data": "close_msg", "style": "danger"}
    ])
    return {"inline_keyboard": rows}


def services_keyboard() -> Dict[str, Any]:
    conn = get_db()
    rows = conn.execute("SELECT * FROM services WHERE is_active = 1 ORDER BY id ASC").fetchall()
    conn.close()

    kb = []
    for r in rows:
        kb.append([{
            "text": f"{r['icon']} {r['name']}",
            "callback_data": f"srv:{r['id']}",
            "style": "primary"
        }])
    kb.append([
        {"text": "🏠 Main Menu", "callback_data": "menu:start", "style": "primary"},
        {"text": "❌ Close", "callback_data": "close_msg", "style": "danger"}
    ])
    return {"inline_keyboard": kb}


def countries_keyboard(service_id: int) -> Dict[str, Any]:
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM countries WHERE service_id = ? AND is_active = 1 ORDER BY id ASC",
        (service_id,)
    ).fetchall()
    conn.close()

    kb = []
    for r in rows:
        kb.append([{
            "text": f"{r['flag']} {r['name']}",
            "callback_data": f"cnt:{service_id}:{r['id']}",
            "style": "success"
        }])
    kb.append([{"text": "⬅️ Back", "callback_data": "back_services", "style": "danger"}])
    return {"inline_keyboard": kb}


def strip_country_code(phone: str, dial_code: str) -> str:
    p = phone.strip()
    d = dial_code.strip()
    if p.startswith(d):
        return p[len(d):].lstrip()
    if p.startswith("+") and d.startswith("+") and p[1:].startswith(d[1:]):
        return p[len(d):].lstrip()
    return p.lstrip("+")


def number_panel_keyboard(session_id: str) -> Tuple[str, Dict[str, Any]]:
    """
    Builds the exact Number Panel seen in video:
    Header: 💠 Tap on a number to copy:
    Button 1 (Green): [🛍️ Shopee] or [✖️ Twitter]
    Button 2..N (Blue, copy_text): [🇧🇿 +5016709162] (or without country code)
    Toggle Button (Blue): [🔖 Without Country Code] or [🔖 With Country Code]
    Row: [💹 Change Number (Red)] [🛍️ OTP Group (Blue URL)]
    Row: [❌ Close (Red)]
    """
    conn = get_db()
    sess = conn.execute("SELECT * FROM number_sessions WHERE session_id = ?", (session_id,)).fetchone()
    expired_msg = "⚠️ <b>Session Closed.</b>\n📩 This number has expired. Please get a new one."
    expired_kb = {
        "inline_keyboard": [[{"text": "❌ Number Expired", "callback_data": "expired_notice", "style": "danger"}]]
    }

    if not sess or sess["is_expired"]:
        conn.close()
        return expired_msg, expired_kb

    srv = conn.execute("SELECT * FROM services WHERE id = ?", (sess["service_id"],)).fetchone()
    cnt = conn.execute("SELECT * FROM countries WHERE id = ?", (sess["country_id"],)).fetchone()
    conn.close()

    srv_name = srv["name"].title() if srv else "Service"
    srv_icon = srv["icon"] if srv else "☑️"
    flag = cnt["flag"] if cnt else "🌐"
    dial_code = cnt["dial_code"] if cnt else "+"

    numbers_list: List[str] = json.loads(sess["numbers_json"])
    show_cc = bool(sess["show_country_code"])

    kb = []
    kb.append([{
        "text": f"{srv_icon} {srv_name}",
        "callback_data": f"noop:{session_id}",
        "style": "success"
    }])

    for num in numbers_list:
        display_num = num if show_cc else strip_country_code(num, dial_code)
        kb.append([{
            "text": f"{flag} {display_num}",
            "copy_text": {"text": display_num},
            "style": "primary"
        }])

    toggle_label = "🔖 Without Country Code" if show_cc else "🔖 With Country Code"
    kb.append([{
        "text": toggle_label,
        "callback_data": f"togcc:{session_id}",
        "style": "primary"
    }])

    otp_group_url = get_setting("otp_group_url", "https://t.me/")
    kb.append([
        {"text": "💹 Change Number", "callback_data": f"chgnum:{session_id}", "style": "danger"},
        {"text": "🛍️ OTP Group", "url": otp_group_url, "style": "primary"}
    ])

    kb.append([{"text": "❌ Close", "callback_data": f"closesess:{session_id}", "style": "danger"}])

    return "💠 <b>Tap on a number to copy:</b>", {"inline_keyboard": kb}


# ===========================================================================
# 🔄 NUMBER ALLOCATION & EXPIRY LOGIC
# ===========================================================================
async def expire_previous_user_sessions(user_id: int) -> None:
    """
    When a user requests a new number, any previously active number session
    is automatically marked as expired and its message in Telegram is updated to:
    '⚠️ Session Closed.
     📩 This number has expired. Please get a new one.
     [❌ Number Expired]'
    just like in the video!
    """
    conn = get_db()
    active_sessions = conn.execute(
        "SELECT * FROM number_sessions WHERE user_id = ? AND is_expired = 0",
        (user_id,)
    ).fetchall()

    for sess in active_sessions:
        conn.execute("UPDATE number_sessions SET is_expired = 1 WHERE session_id = ?", (sess["session_id"],))
        nums = json.loads(sess["numbers_json"])
        for n in nums:
            conn.execute(
                "UPDATE numbers SET status = 'available', assigned_to = NULL WHERE phone = ? AND status = 'assigned'",
                (n,)
            )
        conn.commit()

        if sess["message_id"]:
            expired_text = "⚠️ <b>Session Closed.</b>\n📩 This number has expired. Please get a new one."
            expired_kb = {
                "inline_keyboard": [
                    [{"text": "❌ Number Expired", "callback_data": "expired_notice", "style": "danger"}]
                ]
            }
            asyncio.create_task(
                bot.edit_message_text(
                    chat_id=sess["chat_id"],
                    message_id=sess["message_id"],
                    text=expired_text,
                    reply_markup=expired_kb
                )
            )
    conn.close()


def allocate_numbers_for_user(user_id: int, service_id: int, country_id: int) -> List[str]:
    conn = get_db()
    cur = conn.cursor()

    srv = cur.execute("SELECT * FROM services WHERE id = ?", (service_id,)).fetchone()
    cnt = cur.execute("SELECT * FROM countries WHERE id = ?", (country_id,)).fetchone()
    needed = srv["numbers_per_click"] if srv else 1

    avail_rows = cur.execute(
        "SELECT * FROM numbers WHERE service_id = ? AND country_id = ? AND status = 'available' ORDER BY RANDOM() LIMIT ?",
        (service_id, country_id, needed)
    ).fetchall()

    chosen_phones = [r["phone"] for r in avail_rows]

    if len(chosen_phones) < needed:
        more_needed = needed - len(chosen_phones)
        fallback_rows = cur.execute(
            "SELECT * FROM numbers WHERE service_id = ? AND country_id = ? ORDER BY assigned_at ASC LIMIT ?",
            (service_id, country_id, more_needed)
        ).fetchall()
        for r in fallback_rows:
            if r["phone"] not in chosen_phones:
                chosen_phones.append(r["phone"])

    if not chosen_phones:
        conn.close()
        return []

    now = time.time()
    for ph in chosen_phones:
        cur.execute(
            "UPDATE numbers SET status = 'assigned', assigned_to = ?, assigned_at = ? WHERE phone = ?",
            (user_id, now, ph)
        )

    conn.commit()
    conn.close()
    return chosen_phones


# ===========================================================================
# 📩 OTP RECEIVER & GROUP BROADCASTER (EXACT MATCH TO "QUICK ⚡ OTP" GROUP)
# ===========================================================================
def mask_phone_for_group(phone: str) -> str:
    p = phone.strip()
    if len(p) <= 7:
        return p
    prefix = p[:5]
    suffix = p[-3:]
    return f"{prefix}****{suffix}"


def extract_otp_code(sms_text: str) -> str:
    m = re.search(r"\b(\d{4,8})\b", sms_text)
    return m.group(1) if m else "123456"


def map_service_alias(raw_service: Optional[str]) -> Optional[sqlite3.Row]:
    if not raw_service:
        return None
    raw = raw_service.strip().upper()
    conn = get_db()
    row = conn.execute("SELECT * FROM services WHERE UPPER(name) = ?", (raw,)).fetchone()
    if row:
        conn.close()
        return row
    alias_map = {
        "FB": "FACEBOOK",
        "META": "FACEBOOK",
        "IG": "INSTAGRAM",
        "INSTA": "INSTAGRAM",
        "SHOP": "SHOPEE",
        "SHOPE": "SHOPEE",
        "TT": "TIKTOK",
        "TIK": "TIKTOK",
        "TW": "TWITTER",
        "X": "TWITTER",
        "TWITTER FORGET": "TWITTER FORGET",
    }
    target_name = alias_map.get(raw)
    if target_name:
        row = conn.execute("SELECT * FROM services WHERE UPPER(name) = ?", (target_name,)).fetchone()
        if row:
            conn.close()
            return row
    row = conn.execute("SELECT * FROM services WHERE UPPER(name) LIKE ? OR ? LIKE ('%' || UPPER(name) || '%')", (f"%{raw}%", raw)).fetchone()
    conn.close()
    return row


def detect_service_from_sms(full_sms: str) -> Optional[sqlite3.Row]:
    if not full_sms:
        return None
    t = full_sms.upper()
    conn = get_db()
    active_services = conn.execute("SELECT * FROM services WHERE is_active = 1").fetchall()
    conn.close()

    for s in active_services:
        s_name = s["name"].upper()
        if s_name in t:
            return s
        if s_name == "FACEBOOK" and ("FB" in t or "META" in t):
            return s
        if s_name == "INSTAGRAM" and ("INSTA" in t or "IG" in t):
            return s
        if s_name == "SHOPEE" and "SHOP" in t:
            return s
        if s_name == "TIKTOK" and ("TIKTOK" in t or "TIK TOK" in t):
            return s
        if s_name == "TWITTER" and ("TWITTER" in t or "X.COM" in t):
            return s
        if s_name == "HUAWEI" and "HUAWEI" in t:
            return s
        if s_name == "UBER" and "UBER" in t:
            return s
        if s_name == "BATERY" and "BATERY" in t:
            return s
        if "MASTERCARD" in s_name and "MASTERCARD" in t:
            return s
    return None


def detect_country_flag_from_phone(phone: str) -> str:
    p = phone.strip().lstrip("+")
    dial_flags = [
        ("998", "🇺🇿"),
        ("7", "🇷🇺"),
        ("84", "🇻🇳"),
        ("501", "🇧🇿"),
        ("244", "🇦🇴"),
        ("967", "🇾🇪"),
        ("237", "🇨🇲"),
        ("880", "🇧🇩"),
        ("91", "🇮🇳"),
        ("92", "🇵🇰"),
        ("93", "🇦🇫"),
        ("62", "🇮🇩"),
        ("63", "🇵🇭"),
        ("1", "🇺🇸"),
    ]
    for dial, flag in dial_flags:
        if p.startswith(dial):
            return flag
    return "🌐"


async def process_incoming_otp(
    phone: str,
    full_sms: str,
    otp_code: Optional[str] = None,
    service_override: Optional[str] = None
) -> Dict[str, Any]:
    clean_phone = phone.strip()
    if not clean_phone.startswith("+"):
        clean_phone = "+" + clean_phone
    raw_phone = clean_phone.lstrip("+")

    code = otp_code.strip() if otp_code else extract_otp_code(full_sms)

    detected_srv = map_service_alias(service_override) or detect_service_from_sms(full_sms)

    conn = get_db()
    cur = conn.cursor()

    assigned_user_id = None
    service_name = detected_srv["name"].title() if detected_srv else (service_override or "Service")
    service_icon = detected_srv["icon"] if detected_srv else "☑️"
    country_flag = detect_country_flag_from_phone(clean_phone)
    otp_rate = float(detected_srv["otp_rate"]) if detected_srv else float(get_setting("default_otp_rate", "2.5"))

    # 1. Search in active unexpired number sessions first!
    sess_query = """
        SELECT ns.*, s.name as srv_name, s.icon as srv_icon, s.otp_rate as srv_rate, c.flag as cnt_flag
        FROM number_sessions ns
        LEFT JOIN services s ON ns.service_id = s.id
        LEFT JOIN countries c ON ns.country_id = c.id
        WHERE ns.is_expired = 0
          AND (ns.numbers_json LIKE ? OR ns.numbers_json LIKE ?)
    """
    params = [f"%{clean_phone}%", f"%{raw_phone}%"]
    if detected_srv:
        sess_query += " ORDER BY (CASE WHEN ns.service_id = ? THEN 0 ELSE 1 END), ns.created_at DESC"
        params.append(detected_srv["id"])
    else:
        sess_query += " ORDER BY ns.created_at DESC"

    active_sess = cur.execute(sess_query, tuple(params)).fetchone()

    if active_sess:
        assigned_user_id = active_sess["user_id"]
        if active_sess["srv_name"]:
            service_name = active_sess["srv_name"].title()
            service_icon = active_sess["srv_icon"] or service_icon
            otp_rate = float(active_sess["srv_rate"])
        if active_sess["cnt_flag"]:
            country_flag = active_sess["cnt_flag"]
    else:
        # 2. Search in numbers table
        num_query = """
            SELECT n.*, s.name as srv_name, s.icon as srv_icon, s.otp_rate as srv_rate, c.flag as cnt_flag
            FROM numbers n
            LEFT JOIN services s ON n.service_id = s.id
            LEFT JOIN countries c ON n.country_id = c.id
            WHERE (n.phone = ? OR REPLACE(n.phone, '+', '') = ?)
        """
        num_params = [clean_phone, raw_phone]
        if detected_srv:
            num_query += " ORDER BY (CASE WHEN n.service_id = ? THEN 0 ELSE 1 END), (CASE WHEN n.status = 'assigned' AND n.assigned_to IS NOT NULL THEN 0 ELSE 1 END), n.assigned_at DESC"
            num_params.append(detected_srv["id"])
        else:
            num_query += " ORDER BY (CASE WHEN n.status = 'assigned' AND n.assigned_to IS NOT NULL THEN 0 ELSE 1 END), n.assigned_at DESC"

        num_row = cur.execute(num_query, tuple(num_params)).fetchone()
        if num_row:
            assigned_user_id = num_row["assigned_to"]
            if num_row["srv_name"]:
                service_name = num_row["srv_name"].title()
                service_icon = num_row["srv_icon"] or service_icon
                otp_rate = float(num_row["srv_rate"])
            if num_row["cnt_flag"]:
                country_flag = num_row["cnt_flag"]

    ref_comm = float(get_setting("ref_commission", "0.1"))
    if assigned_user_id:
        cur.execute(
            "UPDATE users SET balance = balance + ?, total_otps = total_otps + 1 WHERE user_id = ?",
            (otp_rate, assigned_user_id)
        )
        u_row = cur.execute("SELECT referred_by FROM users WHERE user_id = ?", (assigned_user_id,)).fetchone()
        if u_row and u_row["referred_by"]:
            cur.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                (ref_comm, u_row["referred_by"])
            )

    cur.execute("""
        INSERT INTO otp_logs (phone, service_name, country_flag, otp_code, full_sms, user_id, reward, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        clean_phone,
        service_name,
        country_flag,
        code,
        full_sms,
        assigned_user_id,
        otp_rate if assigned_user_id else 0.0,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))
    conn.commit()
    conn.close()

    masked_num = mask_phone_for_group(clean_phone)
    bot_username = get_setting("bot_username", "numberotptest_bot").lstrip("@")
    bot_deep_link = f"https://t.me/{bot_username}"
    channel_url = get_setting("channel_url", "https://t.me/")

    group_text = (
        f"{country_flag} | {service_icon} <b>{service_name}</b> | <code>{masked_num}</code> | 🔉 #EN\n"
        f"<blockquote>{full_sms}</blockquote>"
    )
    group_kb = {
        "inline_keyboard": [
            [
                {"text": f"🛡️ {code}", "copy_text": {"text": str(code)}, "style": "success"},
                {"text": "📩 Full SMS", "copy_text": {"text": full_sms}, "style": "primary"}
            ],
            [
                {"text": "⚪ Get Numbers", "url": bot_deep_link, "style": "primary"},
                {"text": "📊 Channel", "url": channel_url, "style": "primary"}
            ]
        ]
    }

    otp_group_chat_id = get_setting("otp_group_chat_id", "").strip()
    group_sent = False
    if otp_group_chat_id:
        res = await bot.send_message(chat_id=otp_group_chat_id, text=group_text, reply_markup=group_kb)
        group_sent = bool(res.get("ok"))

    user_notified = False
    if assigned_user_id:
        dm_text = (
            f"🎉 <b>NEW OTP RECEIVED!</b>\n"
            f"➖➖➖➖➖➖➖➖➖➖\n"
            f"{country_flag} <b>Service:</b> {service_icon} {service_name}\n"
            f"📱 <b>Number:</b> <code>{clean_phone}</code>\n"
            f"🔑 <b>OTP Code:</b> <code>{code}</code>\n"
            f"💰 <b>Earned:</b> +{otp_rate:.2f}৳\n\n"
            f"<blockquote>{full_sms}</blockquote>"
        )
        res_dm = await bot.send_message(chat_id=assigned_user_id, text=dm_text, reply_markup=group_kb)
        user_notified = bool(res_dm.get("ok"))

    return {
        "ok": True,
        "phone": clean_phone,
        "masked_phone": masked_num,
        "otp_code": code,
        "service": service_name,
        "assigned_user_id": assigned_user_id,
        "reward_credited": otp_rate if assigned_user_id else 0.0,
        "group_sent": group_sent,
        "user_notified": user_notified
    }


# ===========================================================================
# 🛠️ IN-BOT ADMIN PANEL (/admin)
# ===========================================================================
def get_all_admin_ids() -> List[int]:
    ids = set(ADMIN_IDS)
    try:
        conn = get_db()
        rows = conn.execute("SELECT user_id FROM admins").fetchall()
        conn.close()
        for r in rows:
            ids.add(int(r["user_id"]))
    except Exception:
        pass
    return sorted(ids)


def is_user_admin(user_id: int) -> bool:
    return user_id in get_all_admin_ids()


def add_admin_db(target_uid: int, added_by: int = 0) -> None:
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO admins (user_id, role, added_by, added_at) VALUES (?, 'admin', ?, ?)",
        (target_uid, added_by, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    )
    conn.commit()
    conn.close()


def remove_admin_db(target_uid: int) -> bool:
    if target_uid in ADMIN_IDS:
        return False  # Primary owner cannot be removed
    conn = get_db()
    conn.execute("DELETE FROM admins WHERE user_id = ?", (target_uid,))
    conn.commit()
    conn.close()
    return True


def build_user_manage_card(target_uid: int) -> Tuple[str, Dict[str, Any]]:
    conn = get_db()
    u = conn.execute("SELECT * FROM users WHERE user_id = ?", (target_uid,)).fetchone()
    conn.close()

    if not u:
        return f"❌ User <code>{target_uid}</code> not found in database!", {
            "inline_keyboard": [[{"text": "⬅️ Back to User Manager", "callback_data": "adm:users", "style": "primary"}]]
        }

    is_adm = is_user_admin(target_uid)
    is_owner = target_uid in ADMIN_IDS
    is_ban = bool(u["is_banned"])
    role_badge = "👑 Owner / Super Admin" if is_owner else ("🛡️ Admin" if is_adm else "👤 Regular User")
    status_badge = "🚫 BANNED" if is_ban else "🟢 Active"
    uname_str = f"@{u['username']}" if u["username"] else "None"

    text = (
        "👤 <b>USER PROFILE & BALANCE MANAGER</b>\n"
        "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
        f"🆔 <b>User ID:</b> <code>{u['user_id']}</code>\n"
        f"🙍‍♂️ <b>Name:</b> {u['first_name']}\n"
        f"🔗 <b>Username:</b> {uname_str}\n"
        f"🎭 <b>Role:</b> <b>{role_badge}</b>\n"
        f"📡 <b>Status:</b> <b>{status_badge}</b>\n\n"
        f"💳 <b>Current Balance:</b> <b>{u['balance']:.2f} ৳</b>\n"
        f"📩 <b>Total OTPs:</b> {u['total_otps']}\n"
        f"👥 <b>Total Invites:</b> {u['total_invites']}\n"
        f"📅 <b>Joined:</b> {u['joined_at']}"
    )

    ban_btn = (
        {"text": "✅ Unban User", "callback_data": f"adm_u_ban:{target_uid}:0", "style": "success"}
        if is_ban
        else {"text": "🚫 Ban User", "callback_data": f"adm_u_ban:{target_uid}:1", "style": "danger"}
    )
    adm_btn = (
        {"text": "👑 Remove from Admin", "callback_data": f"adm_u_role:{target_uid}:0", "style": "danger"}
        if is_adm
        else {"text": "🛡️ Make Admin", "callback_data": f"adm_u_role:{target_uid}:1", "style": "success"}
    )

    kb = [
        [
            {"text": "➕ Add Balance", "callback_data": f"adm_u_bal:{target_uid}:add", "style": "success"},
            {"text": "➖ Deduct Balance", "callback_data": f"adm_u_bal:{target_uid}:sub", "style": "danger"}
        ],
        [
            {"text": "✏️ Set Exact Balance", "callback_data": f"adm_u_bal:{target_uid}:set", "style": "primary"},
            {"text": "🔄 Reset Balance (0৳)", "callback_data": f"adm_u_bal:{target_uid}:zero", "style": "danger"}
        ],
        [ban_btn, adm_btn],
        [{"text": "✉️ Send Direct Message", "callback_data": f"adm_u_msg:{target_uid}", "style": "primary"}],
        [{"text": "⬅️ Back to User & Admin Manager", "callback_data": "adm:users", "style": "primary"}]
    ]
    return text, {"inline_keyboard": kb}


def admin_main_keyboard() -> Dict[str, Any]:
    w_enabled = get_setting("withdrawals_enabled", "0") == "1"
    w_label = "🟢 Withdrawals: ON (Click to Disable)" if w_enabled else "🔴 Withdrawals: OFF (Click to Enable)"
    return {
        "inline_keyboard": [
            [
                {"text": "📊 Dashboard Stats", "callback_data": "adm:stats", "style": "primary"},
                {"text": "⚡ Fire Test OTP", "callback_data": "adm:fire_otp", "style": "success"}
            ],
            [
                {"text": "👥 Manage Users & Balances", "callback_data": "adm:users", "style": "success"},
                {"text": "🛡️ Manage Admins", "callback_data": "adm:admins", "style": "primary"}
            ],
            [
                {"text": "📱 Upload Numbers", "callback_data": "adm:add_nums", "style": "success"},
                {"text": "🛍️ Manage Services & Rates", "callback_data": "adm:services_menu", "style": "primary"}
            ],
            [
                {"text": "🌍 Add Country", "callback_data": "adm:add_cnt", "style": "primary"},
                {"text": "🗑️ Reset Pool", "callback_data": "adm:clear_nums", "style": "danger"}
            ],
            [
                {"text": w_label, "callback_data": "adm:toggle_withdraw", "style": "success" if w_enabled else "danger"}
            ],
            [
                {"text": "💸 Pending Withdrawals", "callback_data": "adm:withdrawals", "style": "primary"},
                {"text": "💰 Edit Rates & Payout", "callback_data": "adm:rates", "style": "primary"}
            ],
            [
                {"text": "🖼️ Bot Intro & Description", "callback_data": "adm:bot_intro", "style": "primary"},
                {"text": "🔌 Number Panel API Setup", "callback_data": "adm:panel_api", "style": "success"}
            ],
            [
                {"text": "🔗 Edit Group/Support Links", "callback_data": "adm:links", "style": "primary"},
                {"text": "📢 Broadcast All", "callback_data": "adm:broadcast", "style": "danger"}
            ],
            [
                {"text": "❌ Close Admin Panel", "callback_data": "close_msg", "style": "danger"}
            ]
        ]
    }


def admin_services_keyboard() -> Dict[str, Any]:
    srvs = get_all_services()
    kb = []
    row = []
    for s in srvs:
        status_dot = "🟢" if s["is_active"] else "🔴"
        row.append({
            "text": f"{s['icon']} {s['name']} ({s['otp_rate']:.1f}৳) {status_dot}",
            "callback_data": f"adm_srv_view:{s['id']}",
            "style": "primary"
        })
        if len(row) == 2:
            kb.append(row)
            row = []
    if row:
        kb.append(row)

    kb.append([
        {"text": "➕ Add New Service", "callback_data": "adm:add_srv", "style": "success"},
        {"text": "💰 Edit Global Rates", "callback_data": "adm:rates", "style": "primary"}
    ])
    kb.append([{"text": "⬅️ Back to Admin Panel", "callback_data": "adm:back_main", "style": "danger"}])
    return {"inline_keyboard": kb}


def admin_service_detail_keyboard(service_id: int, is_active: int) -> Dict[str, Any]:
    toggle_text = "🔴 Deactivate Service" if is_active else "🟢 Activate Service"
    return {
        "inline_keyboard": [
            [
                {"text": "💰 Change Rate (টাকা পরিবর্তন)", "callback_data": f"adm_srv_editrate:{service_id}", "style": "success"},
                {"text": "✏️ Edit Name & Icon", "callback_data": f"adm_srv_editinfo:{service_id}", "style": "primary"}
            ],
            [
                {"text": "🗑️ Delete All Numbers (নাম্বার ডিলিট)", "callback_data": f"adm_srv_clearnums:{service_id}", "style": "danger"},
                {"text": toggle_text, "callback_data": f"adm_srv_toggle:{service_id}", "style": "primary"}
            ],
            [
                {"text": "🗑️ Delete Entire Service (সার্ভিস মুছুন)", "callback_data": f"adm_srv_delconfirm:{service_id}", "style": "danger"}
            ],
            [
                {"text": "⬅️ Back to Services List", "callback_data": "adm:services_menu", "style": "danger"}
            ]
        ]
    }


def admin_service_delconfirm_keyboard(service_id: int) -> Dict[str, Any]:
    return {
        "inline_keyboard": [
            [
                {"text": "⚠️ YES, DELETE PERMANENTLY", "callback_data": f"adm_srv_delyes:{service_id}", "style": "danger"},
                {"text": "❌ CANCEL", "callback_data": f"adm_srv_view:{service_id}", "style": "primary"}
            ]
        ]
    }


def get_system_stats() -> Dict[str, Any]:
    conn = get_db()
    total_users = conn.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
    total_nums = conn.execute("SELECT COUNT(*) as c FROM numbers").fetchone()["c"]
    avail_nums = conn.execute("SELECT COUNT(*) as c FROM numbers WHERE status = 'available'").fetchone()["c"]
    total_otps = conn.execute("SELECT COUNT(*) as c FROM otp_logs").fetchone()["c"]
    pending_w = conn.execute("SELECT COUNT(*) as c FROM withdrawals WHERE status = 'pending'").fetchone()["c"]
    total_bal = conn.execute("SELECT COALESCE(SUM(balance), 0) as s FROM users").fetchone()["s"]
    conn.close()
    return {
        "total_users": total_users,
        "total_nums": total_nums,
        "avail_nums": avail_nums,
        "total_otps": total_otps,
        "pending_withdrawals": pending_w,
        "total_user_balance": round(total_bal, 2)
    }


# ===========================================================================
# 💬 TELEGRAM MESSAGE & CALLBACK HANDLERS
# ===========================================================================
async def handle_start_command(chat_id: int, user_dict: Dict[str, Any], text: str) -> None:
    referrer_id = None
    parts = text.split()
    if len(parts) > 1 and parts[1].isdigit():
        referrer_id = int(parts[1])

    user_row, is_new = get_or_create_user(user_dict, referrer_id)
    set_user_state(user_row["user_id"], None)
    await bot.set_chat_menu_button(chat_id=chat_id, menu_button={"type": "commands"})

    welcome_img = get_setting("welcome_image_url", "").strip()
    welcome_custom = get_setting("welcome_text", "").strip()

    if welcome_custom:
        welcome_text = welcome_custom
    else:
        bot_title = get_setting("bot_title", "EHR ⚡ QUICK INCOME OTP BOT")
        welcome_text = (
            f"╭─────────────────────╮\n"
            f"  🅾️ <b>{bot_title}</b>\n"
            f"╰─────────────────────╯\n\n"
            f"🚀 Welcome to the most advanced system.\n\n"
            f"👇 Please select an option to continue:"
        )

    reply_kb = main_reply_keyboard(is_user_admin(user_row["user_id"]))

    if welcome_img:
        res = await bot.send_photo(
            chat_id=chat_id,
            photo=welcome_img,
            caption=welcome_text,
            reply_markup=reply_kb
        )
        if not res.get("ok"):
            await bot.send_message(
                chat_id=chat_id,
                text=welcome_text,
                reply_markup=reply_kb
            )
    else:
        await bot.send_message(
            chat_id=chat_id,
            text=welcome_text,
            reply_markup=reply_kb
        )

    if is_new and referrer_id and referrer_id != user_row["user_id"]:
        await bot.send_message(
            chat_id=referrer_id,
            text=f"🎉 <b>New Referral Joined!</b>\n👤 User: <b>{user_dict.get('first_name', 'User')}</b> joined using your affiliate link!"
        )


async def show_get_number_menu(chat_id: int) -> None:
    text = (
        "💠 <b>SELECT SERVICE</b>\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        "Choose what you need today:"
    )
    await bot.send_message(chat_id=chat_id, text=text, reply_markup=services_keyboard())


async def show_balance_menu(chat_id: int, user_id: int) -> None:
    conn = get_db()
    u = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()

    total_otps = u["total_otps"] if u else 0
    total_refs = u["total_invites"] if u else 0
    balance = u["balance"] if u else 0.0
    min_payout = get_float_setting("min_payout", 100.0)
    w_enabled = get_setting("withdrawals_enabled", "0") == "1"
    methods = get_setting("payment_methods", "Bkash,Nagad,Rocket,Binance").split(",")

    status_line = (
        "✅ <b>Select your preferred payment method below:</b>"
        if w_enabled
        else "⚠️ <b>Withdrawals are currently disabled by Admin.</b>"
    )

    text = (
        "💰 <b>FINANCE & BILLING</b>\n"
        "➖➖➖➖➖➖➖➖➖➖\n\n"
        f"📩 Total OTPs : {total_otps}\n"
        f"👥 Total Refs : {total_refs}\n\n"
        f"💳 CURRENT BALANCE : {balance:.2f}৳\n"
        f"⚠️ Minimum Payout : {min_payout:.1f} ৳\n\n"
        f"👇 Select Payment Method:\n\n"
        f"{status_line}"
    )
    await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=balance_keyboard(w_enabled, methods)
    )


async def show_ref_system_menu(chat_id: int, user_id: int) -> None:
    conn = get_db()
    u = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()

    total_invites = u["total_invites"] if u else 0
    ref_comm = get_setting("ref_commission", "0.1")
    bot_username = get_setting("bot_username", "numberotptest_bot").lstrip("@")
    ref_link = f"https://t.me/{bot_username}?start={user_id}"

    text = (
        "🎁 <b>AFFILIATE PROGRAM</b>\n"
        "➖➖➖➖➖➖➖➖➖➖\n\n"
        f"🔗 Your Link:\n"
        f"{ref_link}\n\n"
        f"👥 Total Invites: {total_invites}\n"
        f"💰 Reward Commission Per OTP From Your Invited Users: {ref_comm} TK"
    )
    await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=affiliate_keyboard(ref_link)
    )


def get_leaderboard_data(limit: int = 10) -> List[sqlite3.Row]:
    conn = get_db()
    rows = conn.execute("""
        SELECT user_id, first_name, username, balance, total_otps, total_invites
        FROM users
        WHERE is_banned = 0 AND (total_otps > 0 OR balance > 0 OR total_invites > 0)
        ORDER BY total_otps DESC, balance DESC, total_invites DESC
        LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return rows


def get_user_rank(user_id: int) -> Tuple[int, Optional[sqlite3.Row]]:
    conn = get_db()
    rows = conn.execute("""
        SELECT user_id, first_name, username, balance, total_otps, total_invites
        FROM users
        WHERE is_banned = 0
        ORDER BY total_otps DESC, balance DESC, total_invites DESC
    """).fetchall()
    conn.close()
    for idx, r in enumerate(rows, start=1):
        if r["user_id"] == user_id:
            return idx, r
    return 0, None


def mask_username(first_name: Optional[str], username: Optional[str], user_id: int) -> str:
    if username:
        u = username.strip().lstrip("@")
        if len(u) <= 3:
            return f"@{u}***"
        return f"@{u[:3]}***{u[-1]}"
    if first_name:
        fn = first_name.strip()
        if len(fn) <= 3:
            return f"{fn}*"
        return f"{fn[:3]}***"
    uid_str = str(user_id)
    return f"User #{uid_str[:3]}***"


async def show_leaderboard_menu(chat_id: int, user_id: int, message_id: Optional[int] = None) -> None:
    top_users = get_leaderboard_data(10)
    user_rank, user_row = get_user_rank(user_id)

    medals = {1: "🥇", 2: "🥈", 3: "🥉"}
    rank_emojis = {4: "4️⃣", 5: "5️⃣", 6: "6️⃣", 7: "7️⃣", 8: "8️⃣", 9: "9️⃣", 10: "🔟"}

    lines = []
    if not top_users:
        lines.append("<i>No active leaderboard data yet. Start grabbing OTPs to get ranked!</i>")
    else:
        for idx, u in enumerate(top_users, start=1):
            badge = medals.get(idx, rank_emojis.get(idx, f"#{idx}"))
            display_name = mask_username(u["first_name"], u["username"], u["user_id"])
            otps = u["total_otps"] or 0
            bal = u["balance"] or 0.0

            is_me = " 👈 <b>(You)</b>" if u["user_id"] == user_id else ""
            lines.append(
                f"{badge} <b>{display_name}</b>{is_me}\n"
                f"     📩 <code>{otps}</code> OTPs | 💰 <code>{bal:.2f}৳</code>"
            )

    body = "\n\n".join(lines)

    my_otps = user_row["total_otps"] if user_row else 0
    my_bal = user_row["balance"] if user_row else 0.0
    rank_str = f"#{user_rank}" if user_rank > 0 else "Unranked"

    header = (
        "🏆 <b>TOP PERFORMERS LEADERBOARD</b>\n"
        "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
        "<i>Top earners & fast OTP workers in EHR Quick Income:</i>\n\n"
    )
    footer = (
        "\n\n➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
        f"👤 <b>Your Status:</b>\n"
        f"🎖️ <b>Rank:</b> <code>{rank_str}</code> | 📩 <b>OTPs:</b> <code>{my_otps}</code> | 💳 <b>Balance:</b> <code>{my_bal:.2f}৳</code>"
    )

    full_text = f"{header}{body}{footer}"
    kb = leaderboard_keyboard()

    if message_id:
        try:
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=full_text, reply_markup=kb)
            return
        except Exception:
            pass
    await bot.send_message(chat_id=chat_id, text=full_text, reply_markup=kb)


async def show_support_menu(chat_id: int) -> None:
    support_url = get_setting("support_url", "https://t.me/EHR_SUPPORT")
    text = (
        "📩 <b>HELP & SUPPORT</b>\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        "Need help? Contact our admins:"
    )
    await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=support_keyboard(support_url)
    )


async def show_admin_panel(chat_id: int) -> None:
    st = get_system_stats()
    otp_grp = get_setting("otp_group_chat_id", "Not Set") or "Not Set"
    text = (
        "⚙️ <b>SUPER ADMIN CONTROL PANEL</b>\n"
        "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
        f"👥 <b>Total Users:</b> {st['total_users']}\n"
        f"📱 <b>Numbers in Pool:</b> {st['avail_nums']} available / {st['total_nums']} total\n"
        f"📩 <b>Total OTPs Processed:</b> {st['total_otps']}\n"
        f"💳 <b>Total User Balances:</b> {st['total_user_balance']:.2f}৳\n"
        f"⏳ <b>Pending Withdrawals:</b> {st['pending_withdrawals']}\n"
        f"📢 <b>OTP Group Chat ID:</b> <code>{otp_grp}</code>\n\n"
        "💡 <i>Quick Admin Commands:</i>\n"
        "• <code>/services</code> (List all Services & Rates)\n"
        "• <code>/setrate ID_OR_NAME RATE</code> (e.g. <code>/setrate facebook 3.0</code>)\n"
        "• <code>/delservice SERVICE_ID</code> (e.g. <code>/delservice 10</code>)\n"
        "• <code>/addservice Name | Icon | Rate | Nums</code>\n"
        "• <code>/sendotp +998939207321 754891 is your X App verification code</code>\n"
        "• <code>/setotpgroup</code> (type inside your OTP Group)\n"
        "• <code>/user USER_ID</code> (Full User & Balance Control Card)\n"
        "• <code>/addbalance USER_ID AMOUNT</code> | <code>/cutbalance USER_ID AMOUNT</code>\n"
        "• <code>/setbalance USER_ID AMOUNT</code>\n"
        "• <code>/addadmin USER_ID</code> | <code>/removeadmin USER_ID</code>\n"
        "• <code>/ban USER_ID</code> | <code>/unban USER_ID</code>"
    )
    await bot.send_message(chat_id=chat_id, text=text, reply_markup=admin_main_keyboard())


async def handle_message(msg: Dict[str, Any]) -> None:
    chat = msg.get("chat", {})
    chat_id = chat.get("id")
    user = msg.get("from", {})
    user_id = user.get("id")
    text = (msg.get("text") or msg.get("caption") or "").strip()
    document = msg.get("document")

    if not chat_id or not user_id:
        return

    # If Admin uploads a .txt / .csv number file while in bulk upload state (or directly with caption)
    if document and is_user_admin(user_id):
        state, temp_data = get_user_state(user_id)
        if state == "adm_awaiting_numbers_bulk":
            file_id = document.get("file_id", "")
            doc_content = await bot.download_document_text(file_id)
            if doc_content:
                await handle_stateful_input(chat_id, user_id, doc_content, state, temp_data)
                return

    u_row, _ = get_or_create_user(user)
    if u_row and u_row["is_banned"] and not is_user_admin(user_id):
        await bot.send_message(
            chat_id=chat_id,
            text="🚫 <b>Your account has been suspended by Admin.</b>\nContact support if you believe this is a mistake."
        )
        return

    if text.startswith("/setotpgroup") and is_user_admin(user_id):
        parts = text.split()
        target_grp = parts[1] if len(parts) > 1 else str(chat_id)
        set_setting("otp_group_chat_id", target_grp)
        await bot.send_message(
            chat_id=chat_id,
            text=f"✅ <b>OTP Group Chat ID Linked Successfully!</b>\nGroup ID: <code>{target_grp}</code>\nAll incoming OTP cards will be posted there automatically."
        )
        return

    if chat.get("type") in ("group", "supergroup"):
        return

    if text.startswith(("/start", "/menu", "/mainmenu")):
        await handle_start_command(chat_id, user, text)
        return

    if text.startswith("/getnumber"):
        set_user_state(user_id, None)
        await show_get_number_menu(chat_id)
        return

    if text.startswith("/balance"):
        set_user_state(user_id, None)
        await show_balance_menu(chat_id, user_id)
        return

    if text.startswith(("/leaderboard", "/top")):
        set_user_state(user_id, None)
        await show_leaderboard_menu(chat_id, user_id)
        return

    if text.startswith(("/referral", "/ref", "/affiliate")):
        set_user_state(user_id, None)
        await show_ref_system_menu(chat_id, user_id)
        return

    if text.startswith(("/support", "/help")):
        set_user_state(user_id, None)
        await show_support_menu(chat_id)
        return

    if text.startswith("/admin") or text == "⚙️ ADMIN PANEL":
        if is_user_admin(user_id):
            set_user_state(user_id, None)
            await show_admin_panel(chat_id)
        else:
            await bot.send_message(chat_id=chat_id, text="⛔ You are not authorized to access the Admin Panel.")
        return

    if text.startswith("/sendotp") and is_user_admin(user_id):
        parts = text.split(maxsplit=2)
        if len(parts) < 3:
            await bot.send_message(
                chat_id=chat_id,
                text="⚠️ <b>Usage:</b>\n<code>/sendotp +998939207321 754891 is your verification code for X App</code>"
            )
            return
        res = await process_incoming_otp(parts[1], parts[2])
        await bot.send_message(
            chat_id=chat_id,
            text=(
                f"✅ <b>OTP Dispatched!</b>\n"
                f"📱 Phone: <code>{res['phone']}</code>\n"
                f"🔑 Code: <code>{res['otp_code']}</code>\n"
                f"👤 Credited User: <code>{res['assigned_user_id']}</code> (+{res['reward_credited']}৳)\n"
                f"📢 Posted to Group: {'Yes' if res['group_sent'] else 'No (Set OTP Group ID first)'}"
            )
        )
        return

    if text.startswith("/user") and is_user_admin(user_id):
        parts = text.split()
        if len(parts) < 2 or not parts[1].isdigit():
            await bot.send_message(chat_id=chat_id, text="⚠️ Usage: <code>/user USER_ID</code>")
            return
        card_text, card_kb = build_user_manage_card(int(parts[1]))
        await bot.send_message(chat_id=chat_id, text=card_text, reply_markup=card_kb)
        return

    if text.startswith(("/addbalance", "/cutbalance", "/setbalance")) and is_user_admin(user_id):
        parts = text.split()
        cmd_name = parts[0].lower()
        if len(parts) < 3:
            await bot.send_message(chat_id=chat_id, text=f"⚠️ Usage: <code>{cmd_name} USER_ID AMOUNT</code>")
            return
        try:
            target_uid = int(parts[1])
            amt = float(parts[2])
            conn = get_db()
            if cmd_name == "/addbalance":
                conn.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amt, target_uid))
                action_msg = f"Added +{amt:.2f}৳"
                user_msg = f"💰 Admin credited <b>+{amt:.2f}৳</b> to your balance!"
            elif cmd_name == "/cutbalance":
                conn.execute("UPDATE users SET balance = MAX(0, balance - ?) WHERE user_id = ?", (amt, target_uid))
                action_msg = f"Deducted -{amt:.2f}৳"
                user_msg = f"⚠️ Admin deducted <b>-{amt:.2f}৳</b> from your balance."
            else:
                conn.execute("UPDATE users SET balance = ? WHERE user_id = ?", (amt, target_uid))
                action_msg = f"Set exact balance to {amt:.2f}৳"
                user_msg = f"💳 Admin updated your balance to <b>{amt:.2f}৳</b>."
            conn.commit()
            conn.close()
            card_text, card_kb = build_user_manage_card(target_uid)
            await bot.send_message(chat_id=chat_id, text=f"✅ <b>{action_msg}</b> for user <code>{target_uid}</code>!\n\n{card_text}", reply_markup=card_kb)
            await bot.send_message(chat_id=target_uid, text=user_msg)
        except Exception as e:
            await bot.send_message(chat_id=chat_id, text=f"❌ Error: {e}")
        return

    if text.startswith(("/addadmin", "/removeadmin")) and is_user_admin(user_id):
        parts = text.split()
        cmd_name = parts[0].lower()
        if len(parts) < 2 or not parts[1].isdigit():
            await bot.send_message(chat_id=chat_id, text=f"⚠️ Usage: <code>{cmd_name} USER_ID</code>")
            return
        target_uid = int(parts[1])
        if cmd_name == "/addadmin":
            add_admin_db(target_uid, user_id)
            await bot.send_message(chat_id=chat_id, text=f"🛡️ User <code>{target_uid}</code> is now an <b>ADMIN</b>!")
            await bot.send_message(chat_id=target_uid, text="🛡️ <b>Congratulations!</b> You have been promoted to <b>Admin</b>! Send /admin to open the Admin Panel.")
        else:
            ok = remove_admin_db(target_uid)
            if ok:
                await bot.send_message(chat_id=chat_id, text=f"🗑️ User <code>{target_uid}</code> has been removed from Admin.")
            else:
                await bot.send_message(chat_id=chat_id, text="⚠️ Cannot remove primary Owner Admin ID!")
        return

    if text.startswith(("/ban", "/unban")) and is_user_admin(user_id):
        parts = text.split()
        cmd_name = parts[0].lower()
        if len(parts) < 2 or not parts[1].isdigit():
            await bot.send_message(chat_id=chat_id, text=f"⚠️ Usage: <code>{cmd_name} USER_ID</code>")
            return
        target_uid = int(parts[1])
        ban_val = 1 if cmd_name == "/ban" else 0
        conn = get_db()
        conn.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (ban_val, target_uid))
        conn.commit()
        conn.close()
        status_txt = "🚫 BANNED" if ban_val else "✅ UNBANNED"
        await bot.send_message(chat_id=chat_id, text=f"{status_txt} user <code>{target_uid}</code>!")
        return

    if text.startswith(("/services", "/servicelist", "/rates")):
        srvs = get_all_services()
        lines = []
        for idx, s in enumerate(srvs, start=1):
            st_dot = "🟢" if s["is_active"] else "🔴"
            lines.append(f"<b>{idx}. {s['icon']} {s['name']}</b> (ID: <code>{s['id']}</code>) — Rate: <code>{s['otp_rate']:.2f}৳</code> | Nums: {s['numbers_per_click']} {st_dot}")
        body = "\n".join(lines) if lines else "<i>No services configured.</i>"
        adm_hint = ""
        if is_user_admin(user_id):
            adm_hint = (
                "\n\n⚙️ <b>Admin Quick Controls:</b>\n"
                "• <code>/setrate &lt;ID or Name&gt; &lt;Rate&gt;</code> (e.g. <code>/setrate facebook 3.5</code>)\n"
                "• <code>/delservice &lt;ID&gt;</code> (e.g. <code>/delservice 10</code>)\n"
                "• <code>/addservice Name | Icon | Rate | Nums</code>"
            )
        await bot.send_message(
            chat_id=chat_id,
            text=f"🛍️ <b>SERVICES & LIVE OTP RATES</b>\n➖➖➖➖➖➖➖➖➖➖\n{body}{adm_hint}"
        )
        return

    if text.startswith("/setrate") and is_user_admin(user_id):
        parts = text.split()
        if len(parts) < 3:
            await bot.send_message(
                chat_id=chat_id,
                text="⚠️ <b>Usage:</b> <code>/setrate &lt;Service_ID_or_Name&gt; &lt;New_Rate&gt;</code>\nExample: <code>/setrate facebook 3.5</code> or <code>/setrate 1 3.0</code>"
            )
            return
        target_srv_raw = parts[1]
        try:
            new_r = float(parts[2])
        except ValueError:
            await bot.send_message(chat_id=chat_id, text="⚠️ Invalid rate number! Example: <code>/setrate 1 3.0</code>")
            return

        target_row = None
        if target_srv_raw.isdigit():
            target_row = get_service_by_id(int(target_srv_raw))
        if not target_row:
            target_row = get_service_by_name(target_srv_raw)

        if not target_row:
            await bot.send_message(chat_id=chat_id, text=f"❌ Service '<code>{target_srv_raw}</code>' not found. Type /services to check IDs.")
            return

        update_service_rate(target_row["id"], new_r)
        await bot.send_message(
            chat_id=chat_id,
            text=f"✅ <b>Rate Updated Successfully!</b>\nService: <b>{target_row['icon']} {target_row['name']}</b> (ID #{target_row['id']})\nNew OTP Rate: <b>{new_r:.2f}৳</b>"
        )
        return

    if text.startswith("/delservice") and is_user_admin(user_id):
        parts = text.split()
        if len(parts) < 2 or not parts[1].isdigit():
            await bot.send_message(chat_id=chat_id, text="⚠️ <b>Usage:</b> <code>/delservice SERVICE_ID</code>\nExample: <code>/delservice 10</code>")
            return
        sid = int(parts[1])
        s_row = get_service_by_id(sid)
        if not s_row:
            await bot.send_message(chat_id=chat_id, text=f"❌ Service ID #{sid} does not exist.")
            return
        delete_service(sid)
        await bot.send_message(
            chat_id=chat_id,
            text=f"✅ <b>Service Deleted!</b>\n<b>{s_row['icon']} {s_row['name']}</b> (ID #{sid}) and all its associated numbers have been removed."
        )
        return

    if text.startswith("/addservice") and is_user_admin(user_id):
        content = text[len("/addservice"):].strip()
        parts = [p.strip() for p in content.split("|")]
        if not parts or not parts[0]:
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    "⚠️ <b>Usage:</b>\n"
                    "<code>/addservice Name | Icon | Rate | NumbersPerClick</code>\n\n"
                    "Example:\n"
                    "<code>/addservice FACEBOOK | 📘 | 2.5 | 1</code>"
                )
            )
            return
        s_name = parts[0].upper()
        s_icon = parts[1] if len(parts) > 1 and parts[1] else "☑️"
        s_rate = float(parts[2]) if len(parts) > 2 and parts[2].replace(".", "").isdigit() else 2.5
        s_num = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 1
        new_sid = add_service(s_name, s_icon, s_rate, s_num)
        await bot.send_message(
            chat_id=chat_id,
            text=f"✅ <b>Service Created!</b>\nID: <code>{new_sid}</code>\nService: <b>{s_icon} {s_name}</b>\nRate: <b>{s_rate:.2f}৳</b> | Numbers/Click: <b>{s_num}</b>\n<i>Default countries automatically seeded.</i>"
        )
        return

    if text.startswith("/addrange") and is_user_admin(user_id):
        # Format: /addrange ServiceID CountryID StartNumber CountOrEndNumber
        # Example: /addrange 10 1 +8801700000000 100
        # Example: /addrange 10 1 +8801700000000 +8801700000100
        parts = text.split()
        if len(parts) < 5:
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    "🔢 <b>GENERATE / UPLOAD NUMBER RANGE</b>\n"
                    "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                    "<b>Usage:</b>\n"
                    "<code>/addrange &lt;ServiceID&gt; &lt;CountryID&gt; &lt;StartNumber&gt; &lt;Count_or_EndNumber&gt;</code>\n\n"
                    "<b>Examples:</b>\n"
                    "• <code>/addrange 10 1 +8801700000000 50</code> (Add 50 sequential numbers)\n"
                    "• <code>/addrange 10 1 +8801700000000 +8801700000050</code> (Start to End range)\n\n"
                    "<i>Tip: Type /services to find Service IDs.</i>"
                )
            )
            return
        try:
            sid = int(parts[1])
            cid = int(parts[2])
            start_raw = parts[3].strip()
            param4 = parts[4].strip()

            prefix = "+" if start_raw.startswith("+") else ""
            start_digits = start_raw.lstrip("+")
            
            if param4.isdigit() and len(param4) <= 5:
                count = int(param4)
            else:
                end_digits = param4.lstrip("+")
                count = max(1, int(end_digits) - int(start_digits) + 1)
            
            if count > 5000:
                await bot.send_message(chat_id=chat_id, text="⚠️ Maximum 5,000 numbers can be generated in one range.")
                return

            start_int = int(start_digits)
            pad_len = len(start_digits)
            
            conn = get_db()
            added = 0
            for i in range(count):
                curr_num = f"{prefix}{str(start_int + i).zfill(pad_len)}"
                conn.execute(
                    "INSERT INTO numbers (service_id, country_id, phone, status) VALUES (?, ?, ?, 'available')",
                    (sid, cid, curr_num)
                )
                added += 1
            conn.commit()
            conn.close()

            await bot.send_message(
                chat_id=chat_id,
                text=(
                    f"✅ <b>Successfully generated & added {added} numbers to pool!</b>\n"
                    f"🏷️ Service ID: <code>{sid}</code> | Country ID: <code>{cid}</code>\n"
                    f"🔢 Start: <code>{prefix}{str(start_int).zfill(pad_len)}</code>\n"
                    f"🔢 End: <code>{prefix}{str(start_int + count - 1).zfill(pad_len)}</code>"
                )
            )
        except Exception as e:
            await bot.send_message(chat_id=chat_id, text=f"❌ Error generating range: {e}")
        return

    if text.startswith("/setdescription") and is_user_admin(user_id):
        desc = text[len("/setdescription"):].strip()
        if not desc:
            await bot.send_message(
                chat_id=chat_id,
                text="⚠️ <b>Usage:</b>\n<code>/setdescription Your bot description here...</code>\n\n<i>This text will appear under 'What can this bot do?' when users first open the bot!</i>"
            )
            return
        set_setting("bot_description", desc)
        res = await bot.set_my_description(desc)
        status_note = "✅ Telegram API synced!" if res.get("ok") else f"⚠️ Telegram Note: {res.get('description', 'Saved in database')}"
        await bot.send_message(
            chat_id=chat_id,
            text=f"📝 <b>Bot Description Updated!</b>\n\n<blockquote>{desc}</blockquote>\n{status_note}"
        )
        return

    if text.startswith("/setbanner") and is_user_admin(user_id):
        img_url = text[len("/setbanner"):].strip()
        if not img_url:
            await bot.send_message(
                chat_id=chat_id,
                text="⚠️ <b>Usage:</b>\n<code>/setbanner https://example.com/banner.jpg</code>\n\n<i>(Send image direct URL or /setbanner clear to remove)</i>"
            )
            return
        if img_url.lower() == "clear":
            set_setting("welcome_image_url", "")
            await bot.send_message(chat_id=chat_id, text="✅ Welcome banner removed.")
            return
        set_setting("welcome_image_url", img_url)
        await bot.send_message(
            chat_id=chat_id,
            text=f"🖼️ <b>Welcome Banner Image Set!</b>\nURL: <code>{img_url}</code>\nNew users will now see this picture when they /start!"
        )
        return

    if text.startswith("/setwelcometext") and is_user_admin(user_id):
        w_text = text[len("/setwelcometext"):].strip()
        if not w_text:
            await bot.send_message(
                chat_id=chat_id,
                text="⚠️ <b>Usage:</b>\n<code>/setwelcometext Welcome to our Bot! Click below to start...</code>\n\n<i>(Send /setwelcometext reset to restore default)</i>"
            )
            return
        if w_text.lower() == "reset":
            set_setting("welcome_text", "")
            await bot.send_message(chat_id=chat_id, text="✅ Welcome text restored to default.")
            return
        set_setting("welcome_text", w_text)
        await bot.send_message(
            chat_id=chat_id,
            text=f"✍️ <b>Welcome Message Text Set!</b>\n\n<blockquote>{w_text}</blockquote>"
        )
        return

    upper_text = text.upper()
    if "GET NUMBER" in upper_text:
        set_user_state(user_id, None)
        await show_get_number_menu(chat_id)
        return
    if "BALANCE" in upper_text:
        set_user_state(user_id, None)
        await show_balance_menu(chat_id, user_id)
        return
    if "LEADERBOARD" in upper_text or "TOP" in upper_text:
        set_user_state(user_id, None)
        await show_leaderboard_menu(chat_id, user_id)
        return
    if "REF. SYSTEM" in upper_text or "REF SYSTEM" in upper_text:
        set_user_state(user_id, None)
        await show_ref_system_menu(chat_id, user_id)
        return
    if "SUPPORT" in upper_text:
        set_user_state(user_id, None)
        await show_support_menu(chat_id)
        return

    state, temp_data = get_user_state(user_id)
    if state:
        await handle_stateful_input(chat_id, user_id, text, state, temp_data)
        return


async def handle_stateful_input(
    chat_id: int,
    user_id: int,
    text: str,
    state: str,
    temp_data: Dict[str, Any]
) -> None:
    if text.lower() in ("/cancel", "cancel", "close"):
        set_user_state(user_id, None)
        await bot.send_message(chat_id=chat_id, text="❌ Operation cancelled.")
        return

    if state == "awaiting_withdraw_account":
        method = temp_data.get("method", "Bkash")
        conn = get_db()
        u = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
        min_payout = get_float_setting("min_payout", 100.0)
        if not u or u["balance"] < min_payout:
            conn.close()
            set_user_state(user_id, None)
            await bot.send_message(chat_id=chat_id, text=f"❌ Insufficient balance! Minimum payout is {min_payout}৳.")
            return

        amount = u["balance"]
        conn.execute("UPDATE users SET balance = 0 WHERE user_id = ?", (user_id,))
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO withdrawals (user_id, amount, method, account_number, status, created_at)
            VALUES (?, ?, ?, ?, 'pending', ?)
        """, (user_id, amount, method, text, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        wid = cur.lastrowid
        conn.commit()
        conn.close()
        set_user_state(user_id, None)

        await bot.send_message(
            chat_id=chat_id,
            text=(
                f"✅ <b>Withdrawal Request Submitted!</b>\n"
                f"➖➖➖➖➖➖➖➖➖➖\n"
                f"🆔 Request ID: #{wid}\n"
                f"💳 Method: <b>{method}</b>\n"
                f"📱 Account: <code>{text}</code>\n"
                f"💰 Amount: <b>{amount:.2f}৳</b>\n\n"
                f"⏳ Please wait while Admin reviews your payout."
            )
        )
        for adm_id in get_all_admin_ids():
            adm_kb = {
                "inline_keyboard": [[
                    {"text": "✅ Approve", "callback_data": f"adm_w_ok:{wid}", "style": "success"},
                    {"text": "❌ Reject & Refund", "callback_data": f"adm_w_no:{wid}", "style": "danger"}
                ]]
            }
            await bot.send_message(
                chat_id=adm_id,
                text=(
                    f"🔔 <b>New Withdrawal Request #{wid}</b>\n"
                    f"👤 User ID: <code>{user_id}</code>\n"
                    f"💳 Method: <b>{method}</b>\n"
                    f"📱 Account: <code>{text}</code>\n"
                    f"💰 Amount: <b>{amount:.2f}৳</b>"
                ),
                reply_markup=adm_kb
            )
        return

    if not is_user_admin(user_id):
        set_user_state(user_id, None)
        return

    if state == "adm_awaiting_service":
        parts = [p.strip() for p in text.split("|")]
        s_name = parts[0].upper()
        s_icon = parts[1] if len(parts) > 1 and parts[1] else "☑️"
        s_rate = float(parts[2]) if len(parts) > 2 and parts[2].replace(".", "").isdigit() else 2.5
        s_cnt = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 1

        new_sid = add_service(s_name, s_icon, s_rate, s_cnt)
        set_user_state(user_id, None)
        await bot.send_message(
            chat_id=chat_id,
            text=f"✅ Service <b>{s_icon} {s_name}</b> added with ID #{new_sid} (Rate: {s_rate}৳, Numbers/Click: {s_cnt})!\n<i>Default countries and numbers were automatically created.</i>"
        )
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_srv_rate":
        sid = temp_data.get("service_id")
        try:
            new_r = float(text.strip())
        except ValueError:
            await bot.send_message(chat_id=chat_id, text="⚠️ Invalid number! Enter a numeric rate (e.g. <code>3.5</code>):")
            return
        update_service_rate(sid, new_r)
        set_user_state(user_id, None)
        s = get_service_by_id(sid)
        s_name = s["name"] if s else f"#{sid}"
        s_icon = s["icon"] if s else "🛍️"
        await bot.send_message(
            chat_id=chat_id,
            text=f"✅ <b>Rate Updated!</b>\nService: <b>{s_icon} {s_name}</b>\nNew OTP Payout: <b>{new_r:.2f}৳</b>"
        )
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_srv_info":
        sid = temp_data.get("service_id")
        parts = [p.strip() for p in text.split("|")]
        s = get_service_by_id(sid)
        if not s:
            set_user_state(user_id, None)
            await bot.send_message(chat_id=chat_id, text="❌ Service not found.")
            return
        new_name = parts[0].upper() if parts and parts[0] else s["name"]
        new_icon = parts[1] if len(parts) > 1 and parts[1] else s["icon"]
        new_cnt = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else s["numbers_per_click"]
        update_service_details(sid, new_name, new_icon, s["otp_rate"], new_cnt)
        set_user_state(user_id, None)
        await bot.send_message(
            chat_id=chat_id,
            text=f"✅ <b>Service Info Updated!</b>\nName: <b>{new_icon} {new_name}</b>\nNumbers/Click: <b>{new_cnt}</b>"
        )
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_bot_desc":
        set_setting("bot_description", text)
        res = await bot.set_my_description(text)
        set_user_state(user_id, None)
        status_note = "✅ Telegram API synced!" if res.get("ok") else f"⚠️ Note: {res.get('description', 'Saved in database')}"
        await bot.send_message(
            chat_id=chat_id,
            text=f"📝 <b>Bot Description Updated!</b>\n\n<blockquote>{text}</blockquote>\n{status_note}"
        )
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_banner_url":
        clean_url = text.strip()
        if clean_url.lower() == "clear":
            clean_url = ""
        set_setting("welcome_image_url", clean_url)
        set_user_state(user_id, None)
        await bot.send_message(
            chat_id=chat_id,
            text=f"🖼️ <b>Welcome Banner Image Updated!</b>\nURL: <code>{clean_url or 'None (Removed)'}</code>"
        )
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_welcome_text":
        clean_txt = text.strip()
        if clean_txt.lower() == "reset":
            clean_txt = ""
        set_setting("welcome_text", clean_txt)
        set_user_state(user_id, None)
        await bot.send_message(
            chat_id=chat_id,
            text=f"✍️ <b>Welcome Message Caption Updated!</b>\n\n<blockquote>{clean_txt or 'Default System Welcome'}</blockquote>"
        )
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_country":
        parts = [p.strip() for p in text.split("|")]
        if len(parts) < 4 or not parts[0].isdigit():
            await bot.send_message(
                chat_id=chat_id,
                text="⚠️ Invalid format! Send like:\n<code>1 | BELIZE | 🇧🇿 | +501</code>"
            )
            return
        sid = int(parts[0])
        cname = parts[1].upper()
        cflag = parts[2]
        cdial = parts[3] if parts[3].startswith("+") else "+" + parts[3]

        conn = get_db()
        conn.execute(
            "INSERT INTO countries (service_id, name, flag, dial_code, is_active) VALUES (?, ?, ?, ?, 1)",
            (sid, cname, cflag, cdial)
        )
        conn.commit()
        conn.close()
        set_user_state(user_id, None)
        await bot.send_message(chat_id=chat_id, text=f"✅ Country <b>{cflag} {cname} ({cdial})</b> added to Service #{sid}!")
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_numbers_bulk":
        country_id = temp_data.get("country_id")
        service_id = temp_data.get("service_id")
        
        # Strip HTML tags if uploaded as .html file or raw HTML text
        clean_text = re.sub(r"<[^>]+>", " ", text)
        raw_tokens = re.split(r"[\r\n,;\t |]+", clean_text)
        
        phones = []
        seen = set()
        for tok in raw_tokens:
            cleaned = re.sub(r"[^0-9+]", "", tok.strip())
            raw_digits = cleaned.lstrip("+")
            if len(raw_digits) >= 6:
                if not cleaned.startswith("+"):
                    cleaned = "+" + cleaned
                if cleaned not in seen:
                    seen.add(cleaned)
                    phones.append(cleaned)
                    
        conn = get_db()
        added = 0
        for ph in phones:
            conn.execute(
                "INSERT INTO numbers (service_id, country_id, phone, status) VALUES (?, ?, ?, 'available')",
                (service_id, country_id, ph)
            )
            added += 1
        conn.commit()
        conn.close()
        set_user_state(user_id, None)
        await bot.send_message(chat_id=chat_id, text=f"✅ Successfully uploaded <b>{added}</b> numbers to the pool!")
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_rates":
        parts = [p.strip() for p in text.split("|")]
        if len(parts) >= 1:
            set_setting("min_payout", parts[0])
        if len(parts) >= 2:
            set_setting("ref_commission", parts[1])
        if len(parts) >= 3:
            set_setting("default_otp_rate", parts[2])
        set_user_state(user_id, None)
        await bot.send_message(chat_id=chat_id, text="✅ Finance & Referral rates updated!")
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_panel_api":
        # Format: API_URL | API_TOKEN | ENABLED(1 or 0)
        parts = [p.strip() for p in text.split("|")]
        if len(parts) >= 1:
            set_setting("panel_api_url", parts[0])
        if len(parts) >= 2:
            set_setting("panel_api_token", parts[1])
        if len(parts) >= 3:
            set_setting("panel_api_enabled", "1" if parts[2] in ("1", "true", "yes", "on", "ON") else "0")
        else:
            set_setting("panel_api_enabled", "1")
        set_user_state(user_id, None)
        await bot.send_message(
            chat_id=chat_id,
            text=(
                "✅ <b>Number Panel API Configured Successfully!</b>\n"
                f"🌐 URL: <code>{get_setting('panel_api_url')}</code>\n"
                f"🔑 Token: <code>{get_setting('panel_api_token') or 'None'}</code>\n"
                f"⚡ Auto-Fetch Status: <b>{'ACTIVE 🟢' if get_setting('panel_api_enabled') == '1' else 'OFF 🔴'}</b>"
            )
        )
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_links":
        parts = [p.strip() for p in text.split("|")]
        if len(parts) >= 1 and parts[0]:
            set_setting("otp_group_url", parts[0])
        if len(parts) >= 2 and parts[1]:
            set_setting("channel_url", parts[1])
        if len(parts) >= 3 and parts[2]:
            set_setting("support_url", parts[2])
        if len(parts) >= 4 and parts[3]:
            set_setting("otp_group_chat_id", parts[3])
        set_user_state(user_id, None)
        await bot.send_message(chat_id=chat_id, text="✅ Links & OTP Group Chat ID updated!")
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_user_lookup":
        q = text.strip().lstrip("@")
        conn = get_db()
        if q.isdigit():
            u = conn.execute("SELECT user_id FROM users WHERE user_id = ?", (int(q),)).fetchone()
        else:
            u = conn.execute("SELECT user_id FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(first_name) LIKE LOWER(?)", (q, f"%{q}%")).fetchone()
        conn.close()
        set_user_state(user_id, None)
        if not u:
            await bot.send_message(chat_id=chat_id, text=f"❌ No user found matching <code>{text}</code>!")
            return
        card_text, card_kb = build_user_manage_card(u["user_id"])
        await bot.send_message(chat_id=chat_id, text=card_text, reply_markup=card_kb)
        return

    if state == "adm_awaiting_user_bal_amount":
        target_uid = int(temp_data.get("target_uid", 0))
        mode = temp_data.get("mode", "add")
        try:
            amt = float(text.strip())
        except Exception:
            await bot.send_message(chat_id=chat_id, text="⚠️ Invalid amount! Please enter a valid number (e.g. 50 or 100.5):")
            return
        conn = get_db()
        if mode == "add":
            conn.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amt, target_uid))
            note = f"💰 Admin credited <b>+{amt:.2f}৳</b> to your balance!"
        elif mode == "sub":
            conn.execute("UPDATE users SET balance = MAX(0, balance - ?) WHERE user_id = ?", (amt, target_uid))
            note = f"⚠️ Admin deducted <b>-{amt:.2f}৳</b> from your balance."
        else:
            conn.execute("UPDATE users SET balance = ? WHERE user_id = ?", (amt, target_uid))
            note = f"💳 Admin updated your balance to <b>{amt:.2f}৳</b>."
        conn.commit()
        conn.close()
        set_user_state(user_id, None)
        await bot.send_message(chat_id=target_uid, text=note)
        card_text, card_kb = build_user_manage_card(target_uid)
        await bot.send_message(chat_id=chat_id, text=f"✅ <b>Balance Updated!</b>\n\n{card_text}", reply_markup=card_kb)
        return

    if state == "adm_awaiting_user_dm":
        target_uid = int(temp_data.get("target_uid", 0))
        set_user_state(user_id, None)
        res = await bot.send_message(chat_id=target_uid, text=f"📩 <b>MESSAGE FROM ADMIN</b>\n➖➖➖➖➖➖➖➖➖➖\n{text}")
        if res.get("ok"):
            await bot.send_message(chat_id=chat_id, text=f"✅ Message sent to user <code>{target_uid}</code>!")
        else:
            await bot.send_message(chat_id=chat_id, text=f"❌ Failed to send message to <code>{target_uid}</code>.")
        return

    if state == "adm_awaiting_new_admin_id":
        q = text.strip()
        if not q.isdigit():
            await bot.send_message(chat_id=chat_id, text="⚠️ Please send a valid numeric Telegram User ID (e.g. <code>7610279126</code>):")
            return
        target_uid = int(q)
        add_admin_db(target_uid, user_id)
        set_user_state(user_id, None)
        await bot.send_message(chat_id=chat_id, text=f"✅ User <code>{target_uid}</code> has been added as an <b>Admin</b>!")
        await bot.send_message(chat_id=target_uid, text="🛡️ <b>Congratulations!</b> You have been promoted to <b>Admin</b>! Send /admin to access the Admin Panel.")
        await show_admin_panel(chat_id)
        return

    if state == "adm_awaiting_broadcast":
        set_user_state(user_id, None)
        conn = get_db()
        users = conn.execute("SELECT user_id FROM users").fetchall()
        conn.close()
        sent = 0
        for u in users:
            res = await bot.send_message(chat_id=u["user_id"], text=f"📢 <b>ANNOUNCEMENT</b>\n➖➖➖➖➖➖➖➖➖➖\n{text}")
            if res.get("ok"):
                sent += 1
        await bot.send_message(chat_id=chat_id, text=f"✅ Broadcast delivered to <b>{sent}</b> users!")
        return


# ===========================================================================
# 🔘 CALLBACK QUERY HANDLER
# ===========================================================================
async def handle_callback_query(cb: Dict[str, Any]) -> None:
    cb_id = cb.get("id")
    user = cb.get("from", {})
    user_id = user.get("id")
    msg = cb.get("message", {})
    chat_id = msg.get("chat", {}).get("id")
    message_id = msg.get("message_id")
    data = cb.get("data", "")

    if not cb_id or not chat_id or not user_id:
        return

    if data == "close_msg":
        await bot.answer_callback_query(cb_id)
        await bot.delete_message(chat_id=chat_id, message_id=message_id)
        return

    if data.startswith("closesess:"):
        sess_id = data.split(":", 1)[1]
        conn = get_db()
        conn.execute("UPDATE number_sessions SET is_expired = 1 WHERE session_id = ?", (sess_id,))
        conn.commit()
        conn.close()
        await bot.answer_callback_query(cb_id, text="Menu Closed")
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text="❌ <b>Menu Closed.</b>"
        )
        return

    if data == "expired_notice":
        await bot.answer_callback_query(
            cb_id,
            text="⚠️ This number has expired. Please tap GET NUMBER to get a new one.",
            show_alert=True
        )
        return

    if data.startswith("fallback_copy:"):
        val = data.split(":", 1)[1]
        await bot.answer_callback_query(cb_id, text=f"📋 Copied: {val}", show_alert=False)
        return

    if data == "withdraw_disabled":
        await bot.answer_callback_query(
            cb_id,
            text="⚠️ Withdrawals are currently disabled by Admin.",
            show_alert=True
        )
        return

    if data.startswith("withdraw_method:"):
        method = data.split(":", 1)[1]
        conn = get_db()
        u = conn.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,)).fetchone()
        conn.close()
        min_payout = get_float_setting("min_payout", 100.0)
        bal = u["balance"] if u else 0.0
        if bal < min_payout:
            await bot.answer_callback_query(
                cb_id,
                text=f"⚠️ Minimum Payout is {min_payout:.1f} ৳! Your current balance is {bal:.2f} ৳.",
                show_alert=True
            )
            return
        set_user_state(user_id, "awaiting_withdraw_account", {"method": method})
        await bot.answer_callback_query(cb_id)
        await bot.send_message(
            chat_id=chat_id,
            text=f"💸 <b>{method} Withdrawal</b>\nPlease enter your <b>{method}</b> account number / UID (or send /cancel):"
        )
        return

    if data.startswith("srv:"):
        service_id = int(data.split(":")[1])
        conn = get_db()
        srv = conn.execute("SELECT * FROM services WHERE id = ?", (service_id,)).fetchone()
        conn.close()
        if not srv:
            await bot.answer_callback_query(cb_id, text="Service unavailable", show_alert=True)
            return

        await bot.answer_callback_query(cb_id)
        region_text = (
            "🌐 <b>SELECT REGION</b>\n"
            "➖➖➖➖➖➖➖➖➖➖\n"
            f"Available countries for <b>{srv['name']}</b>:"
        )
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=region_text,
            reply_markup=countries_keyboard(service_id)
        )
        return

    if data == "back_services":
        await bot.answer_callback_query(cb_id)
        text = (
            "💠 <b>SELECT SERVICE</b>\n"
            "➖➖➖➖➖➖➖➖➖➖\n"
            "Choose what you need today:"
        )
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            reply_markup=services_keyboard()
        )
        return

    if data.startswith("cnt:"):
        _, s_id_str, c_id_str = data.split(":")
        service_id = int(s_id_str)
        country_id = int(c_id_str)

        allocated = allocate_numbers_for_user(user_id, service_id, country_id)
        if not allocated:
            await bot.answer_callback_query(
                cb_id,
                text="⚠️ No numbers available right now! Please upload numbers or try another country.",
                show_alert=True
            )
            return

        await bot.answer_callback_query(cb_id)
        await expire_previous_user_sessions(user_id)

        session_id = f"{user_id}_{int(time.time()*1000)}"

        conn = get_db()
        conn.execute("""
            INSERT INTO number_sessions
            (session_id, user_id, chat_id, message_id, service_id, country_id, numbers_json, show_country_code, is_expired, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, ?)
        """, (session_id, user_id, chat_id, message_id, service_id, country_id, json.dumps(allocated), time.time()))
        conn.commit()
        conn.close()

        panel_text, panel_kb = number_panel_keyboard(session_id)
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=panel_text,
            reply_markup=panel_kb
        )
        return

    if data.startswith("togcc:"):
        session_id = data.split(":", 1)[1]
        conn = get_db()
        sess = conn.execute("SELECT * FROM number_sessions WHERE session_id = ?", (session_id,)).fetchone()
        if not sess or sess["is_expired"]:
            conn.close()
            await bot.answer_callback_query(cb_id, text="⚠️ This number has expired.", show_alert=True)
            return

        new_val = 0 if sess["show_country_code"] else 1
        conn.execute("UPDATE number_sessions SET show_country_code = ? WHERE session_id = ?", (new_val, session_id))
        conn.commit()
        conn.close()

        await bot.answer_callback_query(cb_id, text="✅ Number Format Changed!", show_alert=False)
        panel_text, panel_kb = number_panel_keyboard(session_id)
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=panel_text,
            reply_markup=panel_kb
        )
        return

    if data.startswith("chgnum:"):
        session_id = data.split(":", 1)[1]
        conn = get_db()
        sess = conn.execute("SELECT * FROM number_sessions WHERE session_id = ?", (session_id,)).fetchone()
        if not sess or sess["is_expired"]:
            conn.close()
            await bot.answer_callback_query(cb_id, text="⚠️ Session expired.", show_alert=True)
            return

        u = conn.execute("SELECT last_change_ts FROM users WHERE user_id = ?", (user_id,)).fetchone()
        cooldown = int(get_setting("change_cooldown", "5"))
        now = time.time()
        last_ts = u["last_change_ts"] if u else 0.0
        elapsed = now - last_ts

        if elapsed < cooldown:
            rem = max(1, int(round(cooldown - elapsed)))
            conn.close()
            await bot.answer_callback_query(
                cb_id,
                text=f"⏳ Please wait {rem}s.",
                show_alert=True
            )
            return

        old_nums = json.loads(sess["numbers_json"])
        for n in old_nums:
            conn.execute(
                "UPDATE numbers SET status = 'available', assigned_to = NULL WHERE phone = ? AND status = 'assigned'",
                (n,)
            )
        conn.execute("UPDATE users SET last_change_ts = ? WHERE user_id = ?", (now, user_id))
        conn.commit()
        conn.close()

        new_nums = allocate_numbers_for_user(user_id, sess["service_id"], sess["country_id"])
        conn = get_db()
        conn.execute(
            "UPDATE number_sessions SET numbers_json = ?, created_at = ? WHERE session_id = ?",
            (json.dumps(new_nums), now, session_id)
        )
        conn.commit()
        conn.close()

        await bot.answer_callback_query(cb_id, text="🔄 Number Changed!", show_alert=False)
        panel_text, panel_kb = number_panel_keyboard(session_id)
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=panel_text,
            reply_markup=panel_kb
        )
        return

    if data == "menu:start":
        await bot.answer_callback_query(cb_id)
        await handle_start_command(chat_id, user, "/start")
        return

    if data in ("refresh_leaderboard", "menu:leaderboard"):
        await bot.answer_callback_query(cb_id, text="🔄 Leaderboard Updated!")
        await show_leaderboard_menu(chat_id, user_id, message_id=message_id)
        return

    if data == "menu:getnumber":
        await bot.answer_callback_query(cb_id)
        text = (
            "💠 <b>SELECT SERVICE</b>\n"
            "➖➖➖➖➖➖➖➖➖➖\n"
            "Choose what you need today:"
        )
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=services_keyboard()
            )
        except Exception:
            await bot.send_message(
                chat_id=chat_id,
                text=text,
                reply_markup=services_keyboard()
            )
        return

    if data == "menu:balance":
        await bot.answer_callback_query(cb_id)
        await show_balance_menu(chat_id, user_id)
        return

    if data == "menu:referral":
        await bot.answer_callback_query(cb_id)
        await show_ref_system_menu(chat_id, user_id)
        return

    if data == "menu:support":
        await bot.answer_callback_query(cb_id)
        await show_support_menu(chat_id)
        return

    if data.startswith("noop:"):
        await bot.answer_callback_query(cb_id, text="👇 Tap on the number below to copy it!")
        return

    if data.startswith("adm:") or data.startswith("adm_"):
        if not is_user_admin(user_id):
            await bot.answer_callback_query(cb_id, text="⛔ Admin only!", show_alert=True)
            return

        if data == "adm:users":
            await bot.answer_callback_query(cb_id)
            conn = get_db()
            users_list = conn.execute("SELECT * FROM users ORDER BY joined_at DESC LIMIT 12").fetchall()
            conn.close()

            kb = [
                [{"text": "🔍 Search User by ID / Username", "callback_data": "adm:search_user", "style": "success"}]
            ]
            for u in users_list:
                ban_icon = "🚫" if u["is_banned"] else ("🛡️" if is_user_admin(u["user_id"]) else "👤")
                uname = f"(@{u['username']})" if u["username"] else ""
                kb.append([{
                    "text": f"{ban_icon} {u['first_name']} {uname} — {u['balance']:.1f}৳ [{u['user_id']}]",
                    "callback_data": f"adm_u_view:{u['user_id']}",
                    "style": "danger" if u["is_banned"] else "primary"
                }])
            kb.append([{"text": "⬅️ Back to Admin Panel", "callback_data": "adm:back_main", "style": "danger"}])

            text = (
                "👥 <b>USER & BALANCE MANAGEMENT</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                "Click on any user below to manage their <b>Balance (+ / - / Set / Reset)</b>, <b>Admin Role</b>, or <b>Ban/Unban</b> status, or tap <b>Search User</b>:"
            )
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup={"inline_keyboard": kb})
            return

        if data == "adm:search_user":
            set_user_state(user_id, "adm_awaiting_user_lookup")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text="🔍 <b>SEARCH USER</b>\nSend the user's <b>Telegram User ID</b>, <b>@username</b>, or <b>Name</b> (or /cancel):"
            )
            return

        if data.startswith("adm_u_view:"):
            target_uid = int(data.split(":")[1])
            await bot.answer_callback_query(cb_id)
            card_text, card_kb = build_user_manage_card(target_uid)
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=card_text, reply_markup=card_kb)
            return

        if data.startswith("adm_u_bal:"):
            _, uid_str, mode = data.split(":")
            target_uid = int(uid_str)
            if mode == "zero":
                conn = get_db()
                conn.execute("UPDATE users SET balance = 0 WHERE user_id = ?", (target_uid,))
                conn.commit()
                conn.close()
                await bot.answer_callback_query(cb_id, text="✅ User balance reset to 0.00৳!", show_alert=True)
                card_text, card_kb = build_user_manage_card(target_uid)
                await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=card_text, reply_markup=card_kb)
                return

            set_user_state(user_id, "adm_awaiting_user_bal_amount", {"target_uid": target_uid, "mode": mode})
            await bot.answer_callback_query(cb_id)
            label_map = {
                "add": "➕ <b>ADD BALANCE</b>\nEnter the amount (৳) to <b>ADD</b> to user",
                "sub": "➖ <b>DEDUCT BALANCE</b>\nEnter the amount (৳) to <b>DEDUCT</b> from user",
                "set": "✏️ <b>SET EXACT BALANCE</b>\nEnter the new exact balance (৳) for user"
            }
            await bot.send_message(
                chat_id=chat_id,
                text=f"{label_map.get(mode, 'Enter amount')} <code>{target_uid}</code> (or /cancel):"
            )
            return

        if data.startswith("adm_u_ban:"):
            _, uid_str, ban_str = data.split(":")
            target_uid = int(uid_str)
            ban_val = int(ban_str)
            if target_uid in ADMIN_IDS and ban_val == 1:
                await bot.answer_callback_query(cb_id, text="⚠️ Cannot ban primary Owner Admin!", show_alert=True)
                return
            conn = get_db()
            conn.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (ban_val, target_uid))
            conn.commit()
            conn.close()
            await bot.answer_callback_query(
                cb_id,
                text="🚫 User Banned!" if ban_val else "✅ User Unbanned!",
                show_alert=True
            )
            card_text, card_kb = build_user_manage_card(target_uid)
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=card_text, reply_markup=card_kb)
            return

        if data.startswith("adm_u_role:"):
            _, uid_str, role_str = data.split(":")
            target_uid = int(uid_str)
            make_adm = int(role_str) == 1
            if make_adm:
                add_admin_db(target_uid, user_id)
                await bot.answer_callback_query(cb_id, text=f"🛡️ User {target_uid} promoted to Admin!", show_alert=True)
                await bot.send_message(
                    chat_id=target_uid,
                    text="🛡️ <b>Congratulations!</b> You have been promoted to <b>Admin</b>! Send /admin to open the Admin Panel."
                )
            else:
                ok = remove_admin_db(target_uid)
                if not ok:
                    await bot.answer_callback_query(cb_id, text="⚠️ Primary Owner Admin cannot be removed!", show_alert=True)
                    return
                await bot.answer_callback_query(cb_id, text=f"🗑️ User {target_uid} removed from Admin!", show_alert=True)
            card_text, card_kb = build_user_manage_card(target_uid)
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=card_text, reply_markup=card_kb)
            return

        if data.startswith("adm_u_msg:"):
            target_uid = int(data.split(":")[1])
            set_user_state(user_id, "adm_awaiting_user_dm", {"target_uid": target_uid})
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text=f"✉️ <b>SEND DIRECT MESSAGE</b>\nType the message to send to user <code>{target_uid}</code> (or /cancel):"
            )
            return

        if data == "adm:admins":
            await bot.answer_callback_query(cb_id)
            all_adms = get_all_admin_ids()
            conn = get_db()
            kb = [
                [{"text": "➕ Add New Admin by User ID", "callback_data": "adm:add_admin_prompt", "style": "success"}]
            ]
            lines = []
            for aid in all_adms:
                u = conn.execute("SELECT first_name, username FROM users WHERE user_id = ?", (aid,)).fetchone()
                name = u["first_name"] if u else "Admin"
                uname = f"(@{u['username']})" if (u and u["username"]) else ""
                is_owner = aid in ADMIN_IDS
                role_lbl = "👑 Owner" if is_owner else "🛡️ Admin"
                lines.append(f"• {role_lbl}: <b>{name}</b> {uname} — <code>{aid}</code>")
                if not is_owner:
                    kb.append([{
                        "text": f"🗑️ Remove Admin: {name} [{aid}]",
                        "callback_data": f"adm_rm_admin:{aid}",
                        "style": "danger"
                    }])
            conn.close()
            kb.append([{"text": "⬅️ Back to Admin Panel", "callback_data": "adm:back_main", "style": "primary"}])
            text = (
                "🛡️ <b>ADMIN TEAM MANAGEMENT</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                + "\n".join(lines)
                + "\n\nTap <b>Add New Admin</b> to promote someone, or tap a button below to remove an admin:"
            )
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup={"inline_keyboard": kb})
            return

        if data == "adm:add_admin_prompt":
            set_user_state(user_id, "adm_awaiting_new_admin_id")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text="🛡️ <b>ADD NEW ADMIN</b>\nSend the <b>Telegram User ID</b> of the person you want to make Admin (or /cancel):"
            )
            return

        if data.startswith("adm_rm_admin:"):
            target_uid = int(data.split(":")[1])
            ok = remove_admin_db(target_uid)
            if not ok:
                await bot.answer_callback_query(cb_id, text="⚠️ Cannot remove primary Owner!", show_alert=True)
                return
            await bot.answer_callback_query(cb_id, text=f"🗑️ Removed {target_uid} from Admin!", show_alert=True)
            # Refresh admin list
            all_adms = get_all_admin_ids()
            conn = get_db()
            kb = [[{"text": "➕ Add New Admin by User ID", "callback_data": "adm:add_admin_prompt", "style": "success"}]]
            lines = []
            for aid in all_adms:
                u = conn.execute("SELECT first_name, username FROM users WHERE user_id = ?", (aid,)).fetchone()
                name = u["first_name"] if u else "Admin"
                uname = f"(@{u['username']})" if (u and u["username"]) else ""
                is_owner = aid in ADMIN_IDS
                role_lbl = "👑 Owner" if is_owner else "🛡️ Admin"
                lines.append(f"• {role_lbl}: <b>{name}</b> {uname} — <code>{aid}</code>")
                if not is_owner:
                    kb.append([{"text": f"🗑️ Remove Admin: {name} [{aid}]", "callback_data": f"adm_rm_admin:{aid}", "style": "danger"}])
            conn.close()
            kb.append([{"text": "⬅️ Back to Admin Panel", "callback_data": "adm:back_main", "style": "primary"}])
            text = "🛡️ <b>ADMIN TEAM MANAGEMENT</b>\n➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n" + "\n".join(lines)
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup={"inline_keyboard": kb})
            return

        if data == "adm:back_main":
            await bot.answer_callback_query(cb_id)
            st = get_system_stats()
            otp_grp = get_setting("otp_group_chat_id", "Not Set") or "Not Set"
            text = (
                "⚙️ <b>SUPER ADMIN CONTROL PANEL</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"👥 <b>Total Users:</b> {st['total_users']}\n"
                f"📱 <b>Numbers in Pool:</b> {st['avail_nums']} available / {st['total_nums']} total\n"
                f"📩 <b>Total OTPs Processed:</b> {st['total_otps']}\n"
                f"💳 <b>Total User Balances:</b> {st['total_user_balance']:.2f}৳\n"
                f"⏳ <b>Pending Withdrawals:</b> {st['pending_withdrawals']}\n"
                f"📢 <b>OTP Group Chat ID:</b> <code>{otp_grp}</code>"
            )
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup=admin_main_keyboard())
            return

        if data == "adm:stats":
            await bot.answer_callback_query(cb_id, text="📊 Stats Refreshed!")
            st = get_system_stats()
            otp_grp = get_setting("otp_group_chat_id", "Not Set") or "Not Set"
            text = (
                "⚙️ <b>SUPER ADMIN CONTROL PANEL</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"👥 <b>Total Users:</b> {st['total_users']}\n"
                f"📱 <b>Numbers in Pool:</b> {st['avail_nums']} available / {st['total_nums']} total\n"
                f"📩 <b>Total OTPs Processed:</b> {st['total_otps']}\n"
                f"💳 <b>Total User Balances:</b> {st['total_user_balance']:.2f}৳\n"
                f"⏳ <b>Pending Withdrawals:</b> {st['pending_withdrawals']}\n"
                f"📢 <b>OTP Group Chat ID:</b> <code>{otp_grp}</code>"
            )
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup=admin_main_keyboard())
            return

        if data == "adm:toggle_withdraw":
            cur_val = get_setting("withdrawals_enabled", "0")
            new_val = "0" if cur_val == "1" else "1"
            set_setting("withdrawals_enabled", new_val)
            status_str = "ENABLED 🟢" if new_val == "1" else "DISABLED 🔴"
            await bot.answer_callback_query(cb_id, text=f"Withdrawals are now {status_str}", show_alert=True)
            await show_admin_panel(chat_id)
            return

        if data == "adm:fire_otp":
            conn = get_db()
            assigned_row = conn.execute(
                "SELECT * FROM numbers WHERE assigned_to IS NOT NULL ORDER BY assigned_at DESC LIMIT 1"
            ).fetchone()
            if not assigned_row:
                assigned_row = conn.execute("SELECT * FROM numbers ORDER BY RANDOM() LIMIT 1").fetchone()
            conn.close()

            phone = assigned_row["phone"] if assigned_row else "+998939207321"
            rand_code = str(random.randint(100000, 999999))
            sample_sms = f"{rand_code} is your verification code for X App."
            res = await process_incoming_otp(phone, sample_sms, rand_code)
            await bot.answer_callback_query(
                cb_id,
                text=f"⚡ Fired OTP {rand_code} to {phone}!",
                show_alert=True
            )
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    f"⚡ <b>Live Test OTP Fired!</b>\n"
                    f"📱 Number: <code>{res['phone']}</code>\n"
                    f"🔑 Code: <code>{res['otp_code']}</code>\n"
                    f"👤 Assigned User: <code>{res['assigned_user_id']}</code> (+{res['reward_credited']}৳)\n"
                    f"📢 Sent to OTP Group: {'✅ Yes' if res['group_sent'] else '⚠️ No (Use /setotpgroup inside your OTP group)'}"
                )
            )
            return

        if data == "adm:services_menu":
            await bot.answer_callback_query(cb_id)
            srvs = get_all_services()
            lines = []
            for s in srvs:
                st_dot = "🟢" if s["is_active"] else "🔴"
                lines.append(f"• {s['icon']} <b>{s['name']}</b> (ID #{s['id']}) — Rate: <b>{s['otp_rate']:.2f}৳</b> {st_dot}")
            body = "\n".join(lines) if lines else "<i>No services found.</i>"
            text = (
                "🛍️ <b>SERVICES & OTP RATES MANAGER</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"Total Services: <b>{len(srvs)}</b>\n\n"
                f"{body}\n\n"
                "👇 <b>Tap any service button below to Change Rate, Edit, or Delete:</b>"
            )
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=admin_services_keyboard()
            )
            return

        if data.startswith("adm_srv_view:"):
            sid = int(data.split(":")[1])
            await bot.answer_callback_query(cb_id)
            s = get_service_by_id(sid)
            if not s:
                await bot.answer_callback_query(cb_id, text="Service not found", show_alert=True)
                return
            conn = get_db()
            cnt_c = conn.execute("SELECT COUNT(*) as c FROM countries WHERE service_id = ?", (sid,)).fetchone()["c"]
            num_c = conn.execute("SELECT COUNT(*) as c FROM numbers WHERE service_id = ? AND status = 'available'", (sid,)).fetchone()["c"]
            conn.close()
            st_str = "🟢 Active" if s["is_active"] else "🔴 Inactive (Hidden)"
            text = (
                f"🛍️ <b>SERVICE CONTROL: {s['icon']} {s['name']}</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"🆔 <b>Service ID:</b> <code>{s['id']}</code>\n"
                f"🏷️ <b>Name:</b> <b>{s['name']}</b>\n"
                f"🎨 <b>Icon Emoji:</b> {s['icon']}\n"
                f"💰 <b>OTP Reward Rate:</b> <b>{s['otp_rate']:.2f} ৳</b>\n"
                f"📱 <b>Numbers Given Per Click:</b> <b>{s['numbers_per_click']}</b>\n"
                f"⚡ <b>Status:</b> <b>{st_str}</b>\n"
                f"🌍 <b>Linked Countries:</b> <b>{cnt_c}</b>\n"
                f"🔢 <b>Available Numbers in Pool:</b> <b>{num_c}</b>\n\n"
                "<i>Select an action below to manage this service:</i>"
            )
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=admin_service_detail_keyboard(sid, s["is_active"])
            )
            return

        if data.startswith("adm_srv_editrate:"):
            sid = int(data.split(":")[1])
            s = get_service_by_id(sid)
            if not s:
                await bot.answer_callback_query(cb_id, text="Service not found", show_alert=True)
                return
            set_user_state(user_id, "adm_awaiting_srv_rate", {"service_id": sid})
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    f"💰 <b>CHANGE RATE: {s['icon']} {s['name']}</b>\n"
                    f"Current OTP Reward Rate: <b>{s['otp_rate']:.2f} ৳</b>\n\n"
                    "Please type and send the <b>new rate</b> in Taka (e.g. <code>3.5</code> or <code>4.0</code>):\n"
                    "<i>(Send /cancel to abort)</i>"
                )
            )
            return

        if data.startswith("adm_srv_editinfo:"):
            sid = int(data.split(":")[1])
            s = get_service_by_id(sid)
            if not s:
                await bot.answer_callback_query(cb_id, text="Service not found", show_alert=True)
                return
            set_user_state(user_id, "adm_awaiting_srv_info", {"service_id": sid})
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    f"✏️ <b>EDIT SERVICE DETAILS: {s['icon']} {s['name']}</b>\n\n"
                    "Send in this format:\n"
                    "<code>ServiceName | IconEmoji | NumbersPerClick</code>\n\n"
                    "Current values:\n"
                    f"<code>{s['name']} | {s['icon']} | {s['numbers_per_click']}</code>\n\n"
                    "<i>(Send /cancel to abort)</i>"
                )
            )
            return

        if data.startswith("adm_srv_toggle:"):
            sid = int(data.split(":")[1])
            new_st = toggle_service_active(sid)
            s = get_service_by_id(sid)
            st_msg = "🟢 Service Activated!" if new_st else "🔴 Service Deactivated!"
            await bot.answer_callback_query(cb_id, text=st_msg, show_alert=True)
            conn = get_db()
            cnt_c = conn.execute("SELECT COUNT(*) as c FROM countries WHERE service_id = ?", (sid,)).fetchone()["c"]
            num_c = conn.execute("SELECT COUNT(*) as c FROM numbers WHERE service_id = ? AND status = 'available'", (sid,)).fetchone()["c"]
            conn.close()
            st_str = "🟢 Active" if new_st else "🔴 Inactive (Hidden)"
            text = (
                f"🛍️ <b>SERVICE CONTROL: {s['icon']} {s['name']}</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"🆔 <b>Service ID:</b> <code>{s['id']}</code>\n"
                f"🏷️ <b>Name:</b> <b>{s['name']}</b>\n"
                f"🎨 <b>Icon Emoji:</b> {s['icon']}\n"
                f"💰 <b>OTP Reward Rate:</b> <b>{s['otp_rate']:.2f} ৳</b>\n"
                f"📱 <b>Numbers Given Per Click:</b> <b>{s['numbers_per_click']}</b>\n"
                f"⚡ <b>Status:</b> <b>{st_str}</b>\n"
                f"🌍 <b>Linked Countries:</b> <b>{cnt_c}</b>\n"
                f"🔢 <b>Available Numbers in Pool:</b> <b>{num_c}</b>"
            )
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=admin_service_detail_keyboard(sid, new_st)
            )
            return

        if data.startswith("adm_srv_clearnums:"):
            sid = int(data.split(":")[1])
            s = get_service_by_id(sid)
            s_name = s["name"] if s else f"#{sid}"
            conn = get_db()
            deleted = conn.execute("DELETE FROM numbers WHERE service_id = ?", (sid,)).rowcount
            conn.commit()
            conn.close()
            await bot.answer_callback_query(cb_id, text=f"🗑️ Deleted {deleted} numbers from {s_name}!", show_alert=True)
            # Refresh service view
            s = get_service_by_id(sid)
            conn = get_db()
            cnt_c = conn.execute("SELECT COUNT(*) as c FROM countries WHERE service_id = ?", (sid,)).fetchone()["c"]
            num_c = conn.execute("SELECT COUNT(*) as c FROM numbers WHERE service_id = ? AND status = 'available'", (sid,)).fetchone()["c"]
            conn.close()
            st_str = "🟢 Active" if s["is_active"] else "🔴 Inactive (Hidden)"
            text = (
                f"🛍️ <b>SERVICE CONTROL: {s['icon']} {s['name']}</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"🆔 <b>Service ID:</b> <code>{s['id']}</code>\n"
                f"🏷️ <b>Name:</b> <b>{s['name']}</b>\n"
                f"🎨 <b>Icon Emoji:</b> {s['icon']}\n"
                f"💰 <b>OTP Reward Rate:</b> <b>{s['otp_rate']:.2f} ৳</b>\n"
                f"📱 <b>Numbers Given Per Click:</b> <b>{s['numbers_per_click']}</b>\n"
                f"⚡ <b>Status:</b> <b>{st_str}</b>\n"
                f"🌍 <b>Linked Countries:</b> <b>{cnt_c}</b>\n"
                f"🔢 <b>Available Numbers in Pool:</b> <b>{num_c}</b>\n\n"
                f"✅ <i>All numbers under {s_name} have been completely removed!</i>"
            )
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=admin_service_detail_keyboard(sid, s["is_active"])
            )
            return

        if data.startswith("adm_srv_delconfirm:"):
            sid = int(data.split(":")[1])
            s = get_service_by_id(sid)
            if not s:
                await bot.answer_callback_query(cb_id, text="Service not found", show_alert=True)
                return
            await bot.answer_callback_query(cb_id)
            text = (
                f"⚠️ <b>DELETE CONFIRMATION</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"Are you sure you want to permanently delete:\n"
                f"<b>{s['icon']} {s['name']} (ID #{sid})</b>?\n\n"
                "🚨 <i>This will delete the service and all numbers/country assignments for this service!</i>"
            )
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=admin_service_delconfirm_keyboard(sid)
            )
            return

        if data.startswith("adm_srv_delyes:"):
            sid = int(data.split(":")[1])
            s = get_service_by_id(sid)
            s_name = s["name"] if s else f"#{sid}"
            delete_service(sid)
            await bot.answer_callback_query(cb_id, text=f"✅ {s_name} Deleted Permanently!", show_alert=True)
            srvs = get_all_services()
            lines = [f"• {x['icon']} <b>{x['name']}</b> (ID #{x['id']}) — Rate: <b>{x['otp_rate']:.2f}৳</b>" for x in srvs]
            body = "\n".join(lines) if lines else "<i>No services configured.</i>"
            text = (
                "🛍️ <b>SERVICES & OTP RATES MANAGER</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"✅ Service #{sid} deleted successfully.\n\n"
                f"Total Services: <b>{len(srvs)}</b>\n\n"
                f"{body}\n\n"
                "👇 <b>Tap any service button below:</b>"
            )
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=admin_services_keyboard()
            )
            return

        if data == "adm:add_srv":
            set_user_state(user_id, "adm_awaiting_service")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    "🛍️ <b>ADD NEW SERVICE</b>\n"
                    "Send in this format:\n"
                    "<code>Service Name | Emoji | RatePerOTP | NumbersPerClick</code>\n\n"
                    "Example:\n"
                    "<code>TELEGRAM | ✈️ | 3.5 | 2</code>\n\n"
                    "<i>(Send /cancel to abort)</i>"
                )
            )
            return

        if data == "adm:add_cnt":
            conn = get_db()
            srvs = conn.execute("SELECT id, icon, name FROM services").fetchall()
            conn.close()
            srv_list = "\n".join([f"ID <code>{s['id']}</code>: {s['icon']} {s['name']}" for s in srvs])
            set_user_state(user_id, "adm_awaiting_country")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    "🌍 <b>ADD NEW COUNTRY TO SERVICE</b>\n"
                    f"Available Services:\n{srv_list}\n\n"
                    "Send in this format:\n"
                    "<code>ServiceID | CountryName | FlagEmoji | DialCode</code>\n\n"
                    "Example:\n"
                    "<code>1 | INDONESIA | 🇮🇩 | +62</code>"
                )
            )
            return

        if data == "adm:add_nums":
            conn = get_db()
            cnts = conn.execute("""
                SELECT c.id, c.name, c.flag, c.dial_code, s.id as sid, s.name as sname
                FROM countries c JOIN services s ON c.service_id = s.id
                ORDER BY s.id ASC, c.id ASC
            """).fetchall()
            conn.close()

            kb = []
            for c in cnts[:25]:
                kb.append([{
                    "text": f"{c['sname']} -> {c['flag']} {c['name']} ({c['dial_code']})",
                    "callback_data": f"adm_pickcnt:{c['sid']}:{c['id']}",
                    "style": "primary"
                }])
            kb.append([{"text": "❌ Cancel", "callback_data": "close_msg", "style": "danger"}])
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text="📱 <b>SELECT SERVICE & COUNTRY TO UPLOAD NUMBERS:</b>",
                reply_markup={"inline_keyboard": kb}
            )
            return

        if data.startswith("adm_pickcnt:"):
            _, sid, cid = data.split(":")
            set_user_state(user_id, "adm_awaiting_numbers_bulk", {"service_id": int(sid), "country_id": int(cid)})
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    "📥 <b>BULK UPLOAD NUMBERS (FILE OR TEXT)</b>\n"
                    "You can now either:\n"
                    "1️⃣ <b>Upload a <code>.txt</code> or <code>.csv</code> Number File</b> directly here in chat!\n"
                    "2️⃣ Or <b>Paste phone numbers</b> as text (one per line or comma-separated):\n\n"
                    "Example:\n"
                    "<code>+998939207321\n+998946917943\n+998936197825</code>"
                )
            )
            return

        if data == "adm:bot_intro":
            await bot.answer_callback_query(cb_id)
            c_desc = get_setting("bot_description", "Not Set (Shows Telegram default)")
            c_img = get_setting("welcome_image_url", "Not Set (Text only)")
            c_txt = get_setting("welcome_text", "Default EHR System Welcome")
            kb = [
                [{"text": "📝 Edit Bot Description (What can this bot do?)", "callback_data": "adm_edit_desc", "style": "primary"}],
                [{"text": "🖼️ Set Welcome Banner Image URL", "callback_data": "adm_edit_banner", "style": "primary"}],
                [{"text": "✍️ Edit Welcome Message Text", "callback_data": "adm_edit_welcometxt", "style": "primary"}],
                [{"text": "🔄 Push Description to Telegram API", "callback_data": "adm_sync_desc", "style": "success"}],
                [{"text": "⬅️ Back to Admin Panel", "callback_data": "adm:back_main", "style": "danger"}]
            ]
            text = (
                "🖼️ <b>BOT INTRO & DESCRIPTION MANAGER</b>\n"
                "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                f"📝 <b>Telegram 'What can this bot do?' Description:</b>\n"
                f"<blockquote>{c_desc}</blockquote>\n\n"
                f"🖼️ <b>Welcome Banner Image URL:</b>\n"
                f"<code>{c_img}</code>\n\n"
                f"✍️ <b>Welcome Text (/start):</b>\n"
                f"<blockquote>{c_txt}</blockquote>\n\n"
                "💡 <i>Tip: The Banner Picture shown on the 'What can this bot do?' card before /start is set via <b>@BotFather -> Edit Bot -> Edit Description Picture</b>.</i>"
            )
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup={"inline_keyboard": kb})
            return

        if data == "adm_edit_desc":
            set_user_state(user_id, "adm_awaiting_bot_desc")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text="📝 <b>EDIT BOT DESCRIPTION</b>\nSend the new description text (this will sync to Telegram's 'What can this bot do?' screen):\n<i>(Send /cancel to abort)</i>"
            )
            return

        if data == "adm_edit_banner":
            set_user_state(user_id, "adm_awaiting_banner_url")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text="🖼️ <b>SET WELCOME BANNER IMAGE</b>\nSend a direct image URL (e.g. <code>https://i.ibb.co/banner.jpg</code>) or send <code>clear</code> to remove:\n<i>(Send /cancel to abort)</i>"
            )
            return

        if data == "adm_edit_welcometxt":
            set_user_state(user_id, "adm_awaiting_welcome_text")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text="✍️ <b>EDIT WELCOME MESSAGE TEXT</b>\nSend the custom welcome text that users will see upon /start (or send <code>reset</code> for default):\n<i>(Send /cancel to abort)</i>"
            )
            return

        if data == "adm_sync_desc":
            desc = get_setting("bot_description", "")
            if desc:
                res = await bot.set_my_description(desc)
                note = "✅ Description synced successfully to Telegram!" if res.get("ok") else f"⚠️ Error: {res.get('description')}"
            else:
                note = "⚠️ No description is set yet. Tap 'Edit Bot Description' first."
            await bot.answer_callback_query(cb_id, text=note[:150], show_alert=True)
            return

        if data == "adm:panel_api":
            set_user_state(user_id, "adm_awaiting_panel_api")
            await bot.answer_callback_query(cb_id)
            cur_url = get_setting("panel_api_url", "Not Set") or "Not Set"
            cur_tok = get_setting("panel_api_token", "Not Set") or "Not Set"
            cur_en = "ON 🟢" if get_setting("panel_api_enabled", "0") == "1" else "OFF 🔴"
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    "🔌 <b>NUMBER PANEL API CONFIGURATION</b>\n"
                    "➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                    f"🌐 <b>Current API URL:</b> <code>{cur_url}</code>\n"
                    f"🔑 <b>Current API Token:</b> <code>{cur_tok}</code>\n"
                    f"⚡ <b>Auto-Pull Status:</b> {cur_en}\n"
                    f"📡 <b>Inbound Webhook URL:</b> <code>http://YOUR_SERVER_IP:{WEB_PORT}/api/otp</code>\n\n"
                    "To connect your Number Panel API, send in this format:\n"
                    "<code>API_URL | API_TOKEN | 1</code>\n\n"
                    "Example:\n"
                    "<code>https://yourpanel.com/api/get_sms | my_secret_token_123 | 1</code>\n\n"
                    "<i>(Send 0 at the end to disable polling, or /cancel to abort)</i>"
                )
            )
            return

        if data == "adm:clear_nums":
            conn = get_db()
            deleted = conn.execute("DELETE FROM numbers").rowcount
            conn.commit()
            conn.close()
            await bot.answer_callback_query(cb_id, text=f"🗑️ Deleted all {deleted} numbers from pool!", show_alert=True)
            await show_admin_panel(chat_id)
            return

        if data == "adm:rates":
            set_user_state(user_id, "adm_awaiting_rates")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    "💰 <b>EDIT PAYOUT & COMMISSION RATES</b>\n"
                    "Send in this format:\n"
                    "<code>MinPayout | RefCommission | DefaultOTPRate</code>\n\n"
                    "Current Values:\n"
                    f"<code>{get_setting('min_payout')} | {get_setting('ref_commission')} | {get_setting('default_otp_rate')}</code>"
                )
            )
            return

        if data == "adm:links":
            set_user_state(user_id, "adm_awaiting_links")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text=(
                    "🔗 <b>EDIT BOT LINKS & OTP GROUP CHAT ID</b>\n"
                    "Send in this format:\n"
                    "<code>OTPGroupURL | ChannelURL | SupportURL | OTPGroupChatID</code>\n\n"
                    "Example:\n"
                    "<code>https://t.me/my_otp_group | https://t.me/my_channel | https://t.me/my_admin | -1001234567890</code>"
                )
            )
            return

        if data == "adm:broadcast":
            set_user_state(user_id, "adm_awaiting_broadcast")
            await bot.answer_callback_query(cb_id)
            await bot.send_message(
                chat_id=chat_id,
                text="📢 <b>SEND BROADCAST MESSAGE</b>\nType or forward the message you want to send to all users (or /cancel):"
            )
            return

        if data == "adm:withdrawals":
            conn = get_db()
            w_rows = conn.execute("SELECT * FROM withdrawals WHERE status = 'pending' ORDER BY id ASC LIMIT 10").fetchall()
            conn.close()
            await bot.answer_callback_query(cb_id)
            if not w_rows:
                await bot.send_message(chat_id=chat_id, text="✅ No pending withdrawal requests!")
                return
            for w in w_rows:
                kb = {
                    "inline_keyboard": [[
                        {"text": "✅ Approve", "callback_data": f"adm_w_ok:{w['id']}", "style": "success"},
                        {"text": "❌ Reject & Refund", "callback_data": f"adm_w_no:{w['id']}", "style": "danger"}
                    ]]
                }
                await bot.send_message(
                    chat_id=chat_id,
                    text=(
                        f"💸 <b>Pending Request #{w['id']}</b>\n"
                        f"👤 User: <code>{w['user_id']}</code>\n"
                        f"💳 Method: <b>{w['method']}</b>\n"
                        f"📱 Account: <code>{w['account_number']}</code>\n"
                        f"💰 Amount: <b>{w['amount']:.2f}৳</b>"
                    ),
                    reply_markup=kb
                )
            return

        if data.startswith("adm_w_ok:"):
            wid = int(data.split(":")[1])
            conn = get_db()
            w = conn.execute("SELECT * FROM withdrawals WHERE id = ?", (wid,)).fetchone()
            if not w or w["status"] != "pending":
                conn.close()
                await bot.answer_callback_query(cb_id, text="Already processed!", show_alert=True)
                return
            conn.execute("UPDATE withdrawals SET status = 'approved' WHERE id = ?", (wid,))
            conn.commit()
            conn.close()
            await bot.answer_callback_query(cb_id, text="✅ Approved!")
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=f"✅ <b>Withdrawal #{wid} APPROVED</b> ({w['amount']:.2f}৳ to {w['method']} {w['account_number']})"
            )
            await bot.send_message(
                chat_id=w["user_id"],
                text=f"🎉 <b>Withdrawal Paid!</b>\nYour payout of <b>{w['amount']:.2f}৳</b> via <b>{w['method']}</b> (<code>{w['account_number']}</code>) has been approved!"
            )
            return

        if data.startswith("adm_w_no:"):
            wid = int(data.split(":")[1])
            conn = get_db()
            w = conn.execute("SELECT * FROM withdrawals WHERE id = ?", (wid,)).fetchone()
            if not w or w["status"] != "pending":
                conn.close()
                await bot.answer_callback_query(cb_id, text="Already processed!", show_alert=True)
                return
            conn.execute("UPDATE withdrawals SET status = 'rejected' WHERE id = ?", (wid,))
            conn.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (w["amount"], w["user_id"]))
            conn.commit()
            conn.close()
            await bot.answer_callback_query(cb_id, text="❌ Rejected & Refunded!")
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=f"❌ <b>Withdrawal #{wid} REJECTED & REFUNDED</b> ({w['amount']:.2f}৳)"
            )
            await bot.send_message(
                chat_id=w["user_id"],
                text=f"⚠️ Your withdrawal request #{wid} ({w['amount']:.2f}৳) was rejected and refunded to your balance."
            )
            return

    # Fallback to ensure callback query loading spinner stops
    try:
        await bot.answer_callback_query(cb_id)
    except Exception:
        pass


# ===========================================================================
# 🌐 WEB ADMIN PANEL & OTP WEBHOOK SERVER (Port 8080)
# ===========================================================================
WEB_ADMIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EHR ⚡ QUICK INCOME - Super Admin & OTP Panel</title>
<style>
  :root { --bg: #0f172a; --card: #1e293b; --accent: #10b981; --danger: #ef4444; --blue: #3b82f6; --text: #f8fafc; --muted: #94a3b8; }
  * { box-sizing: border-box; font-family: 'Segoe UI', system-ui, sans-serif; }
  body { margin: 0; background: var(--bg); color: var(--text); padding: 24px; }
  .container { max-width: 1180px; margin: 0 auto; }
  .header { display: flex; justify-content: space-between; align-items: center; background: var(--card); padding: 20px 24px; border-radius: 14px; margin-bottom: 24px; border: 1px solid #334155; }
  .header h1 { margin: 0; font-size: 22px; color: #38bdf8; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 16px; margin-bottom: 24px; }
  .stat { background: var(--card); padding: 18px; border-radius: 12px; border: 1px solid #334155; }
  .stat span { color: var(--muted); font-size: 13px; text-transform: uppercase; }
  .stat h2 { margin: 8px 0 0; font-size: 28px; color: var(--accent); }
  .panels { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
  @media(max-width: 860px) { .panels { grid-template-columns: 1fr; } }
  .card { background: var(--card); padding: 22px; border-radius: 14px; border: 1px solid #334155; margin-bottom: 20px; }
  .card h3 { margin-top: 0; color: #38bdf8; border-bottom: 1px solid #334155; padding-bottom: 10px; }
  label { display: block; font-size: 13px; color: var(--muted); margin: 10px 0 4px; }
  input, select, textarea { width: 100%; padding: 10px 12px; border-radius: 8px; border: 1px solid #475569; background: #0f172a; color: #fff; font-size: 14px; }
  button { margin-top: 14px; padding: 11px 18px; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; color: #fff; width: 100%; font-size: 14px; }
  .btn-green { background: var(--accent); }
  .btn-blue { background: var(--blue); }
  .btn-red { background: var(--danger); }
  table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }
  th, td { text-align: left; padding: 10px; border-bottom: 1px solid #334155; }
  th { color: var(--muted); }
  .badge { padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }
  .bg-ok { background: rgba(16,185,129,0.2); color: #34d399; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div>
      <h1>⚡ EHR QUICK INCOME — OTP BOT & NUMBER PANEL ADMIN</h1>
      <small style="color:var(--muted)">Live Control Center • Webhook Endpoint: <code>POST /api/otp</code></small>
    </div>
    <a href="/admin" style="color:#38bdf8;text-decoration:none;font-weight:600;">🔄 Refresh</a>
  </div>

  <div class="grid">
    <div class="stat"><span>👥 Total Users</span><h2>{{TOTAL_USERS}}</h2></div>
    <div class="stat"><span>📱 Available Numbers</span><h2>{{AVAIL_NUMS}} / {{TOTAL_NUMS}}</h2></div>
    <div class="stat"><span>📩 Total OTPs Sent</span><h2>{{TOTAL_OTPS}}</h2></div>
    <div class="stat"><span>💳 User Balances</span><h2>{{TOTAL_BAL}} ৳</h2></div>
    <div class="stat"><span>⏳ Pending Payouts</span><h2>{{PENDING_W}}</h2></div>
  </div>

  <div class="panels">
    <div class="card">
      <h3>⚡ Fire / Push Live OTP (To Group & User)</h3>
      <form method="POST" action="/admin/fire_otp">
        <label>Target Phone Number (with country code)</label>
        <input type="text" name="phone" placeholder="+998939207321" required>
        <label>OTP Code (Optional - auto extracted if blank)</label>
        <input type="text" name="otp_code" placeholder="754891">
        <label>Full SMS Content</label>
        <textarea name="full_sms" rows="3" required>754891 - X App uchun tasdiqlash kodingiz</textarea>
        <button type="submit" class="btn-green">🚀 Send OTP to Group & Credit User</button>
      </form>
    </div>

    <div class="card">
      <h3>📥 Bulk Upload Numbers (.TXT / .CSV File or Paste)</h3>
      <form method="POST" action="/admin/upload_numbers">
        <label>Select Service & Country</label>
        <select name="service_country" required>
          {{COUNTRY_OPTIONS}}
        </select>
        <label>📂 Select Number File (.txt / .csv) — Auto Loads Below</label>
        <input type="file" id="numFileInput" accept=".txt,.csv" onchange="if(this.files[0]){var r=new FileReader();r.onload=function(e){document.getElementById('numTextArea').value=e.target.result;};r.readAsText(this.files[0]);}">
        <label>Or Paste Phone Numbers (One per line)</label>
        <textarea id="numTextArea" name="numbers" rows="4" placeholder="+5016709162&#10;+5016740258&#10;+998939207321" required></textarea>
        <button type="submit" class="btn-blue">📱 Upload Numbers to Pool</button>
      </form>
    </div>
  </div>

  <div class="panels">
    <div class="card">
      <h3>⚙️ Finance, Group & Bot Settings</h3>
      <form method="POST" action="/admin/save_settings">
        <label>OTP Group Chat ID (e.g. -1001234567890)</label>
        <input type="text" name="otp_group_chat_id" value="{{OTP_GROUP_CHAT_ID}}">
        <label>OTP Group Invite Link</label>
        <input type="text" name="otp_group_url" value="{{OTP_GROUP_URL}}">
        <label>Main Channel Link</label>
        <input type="text" name="channel_url" value="{{CHANNEL_URL}}">
        <label>Support Contact URL</label>
        <input type="text" name="support_url" value="{{SUPPORT_URL}}">
        <label>Minimum Payout (৳)</label>
        <input type="text" name="min_payout" value="{{MIN_PAYOUT}}">
        <label>Referral Commission per OTP (৳)</label>
        <input type="text" name="ref_commission" value="{{REF_COMM}}">
        <label>Withdrawals Status</label>
        <select name="withdrawals_enabled">
          <option value="0" {{W_OFF}}>🔴 Disabled ("Withdrawals are currently disabled by Admin.")</option>
          <option value="1" {{W_ON}}>🟢 Enabled (Users can request Bkash/Nagad/Rocket/Binance)</option>
        </select>
        <hr style="border:0;border-top:1px solid #334155;margin:14px 0;">
        <label>🔌 External Number Panel API URL (Optional Auto-Pull SMS JSON)</label>
        <input type="text" name="panel_api_url" value="{{PANEL_API_URL}}" placeholder="https://panel.example.com/api/sms">
        <label>🔑 Number Panel API Key / Bearer Token</label>
        <input type="text" name="panel_api_token" value="{{PANEL_API_TOKEN}}" placeholder="Your Panel API Key">
        <label>⚡ Auto-Fetch OTP from Panel API</label>
        <select name="panel_api_enabled">
          <option value="0" {{API_OFF}}>🔴 Off (Use Webhook /api/otp or Manual)</option>
          <option value="1" {{API_ON}}>🟢 Active (Auto-Poll Number Panel API every 8s)</option>
        </select>
        <hr style="border:0;border-top:1px solid #334155;margin:14px 0;">
        <label>📝 Telegram Bot Description ("What can this bot do?" Screen Text)</label>
        <textarea name="bot_description" rows="3" placeholder="Enter text that users see before pressing /start">{{BOT_DESCRIPTION}}</textarea>
        <label>🖼️ Welcome Banner Image URL (Shown upon /start)</label>
        <input type="text" name="welcome_image_url" value="{{WELCOME_IMAGE_URL}}" placeholder="https://example.com/banner.jpg">
        <label>✍️ Welcome Message Text (Shown upon /start)</label>
        <textarea name="welcome_text" rows="3" placeholder="Custom welcome message">{{WELCOME_TEXT}}</textarea>
        <button type="submit" class="btn-blue">💾 Save All Settings & API Config</button>
      </form>
    </div>

    <div class="card">
      <h3>🛍️ Add New Service & Country</h3>
      <form method="POST" action="/admin/add_service_country">
        <label>Service Name (e.g. SHOPEE, TWITTER, WHATSAPP)</label>
        <input type="text" name="srv_name" placeholder="WHATSAPP" required>
        <label>Service Icon Emoji</label>
        <input type="text" name="srv_icon" value="☑️" required>
        <label>OTP Reward Rate (৳) & Numbers Shown Per Click (1 or 2)</label>
        <div style="display:flex;gap:10px;">
          <input type="number" step="0.1" name="srv_rate" value="2.5" required>
          <input type="number" name="srv_num_cnt" value="1" min="1" max="5" required>
        </div>
        <label>Initial Country Name, Flag & Dial Code</label>
        <div style="display:flex;gap:10px;">
          <input type="text" name="cnt_name" placeholder="UZBEKISTAN" required>
          <input type="text" name="cnt_flag" placeholder="🇺🇿" required>
          <input type="text" name="cnt_code" placeholder="+998" required>
        </div>
        <button type="submit" class="btn-green">➕ Create Service & Country</button>
      </form>
    </div>
  </div>

  <div class="panels">
    <div class="card">
      <h3>💳 Manage User Balance & Ban/Unban</h3>
      <form method="POST" action="/admin/manage_user">
        <label>Target Telegram User ID</label>
        <input type="number" name="user_id" placeholder="7610279126" required>
        <label>Action</label>
        <select name="action" required>
          <option value="add_bal">➕ Add Balance (+৳)</option>
          <option value="sub_bal">➖ Deduct Balance (-৳)</option>
          <option value="set_bal">✏️ Set Exact Balance (=৳)</option>
          <option value="zero_bal">🔄 Reset Balance to 0৳</option>
          <option value="ban">🚫 Ban User</option>
          <option value="unban">✅ Unban User</option>
        </select>
        <label>Amount (৳) — (Leave 0 for Ban/Unban/Reset)</label>
        <input type="number" step="0.01" name="amount" value="0">
        <button type="submit" class="btn-green">⚡ Execute User Action</button>
      </form>
    </div>

    <div class="card">
      <h3>🛡️ Add / Remove Bot Admins</h3>
      <form method="POST" action="/admin/manage_admin">
        <label>Telegram User ID</label>
        <input type="number" name="admin_user_id" placeholder="123456789" required>
        <label>Role Action</label>
        <select name="role_action">
          <option value="add">🛡️ Promote to Admin (Full /admin Access)</option>
          <option value="remove">🗑️ Remove from Admin</option>
        </select>
        <button type="submit" class="btn-blue">👑 Update Admin Role</button>
      </form>
      <div style="margin-top:14px;font-size:13px;color:var(--muted);">
        <b>Current Admins:</b> {{ADMIN_LIST_HTML}}
      </div>
    </div>
  </div>

  <div class="card">
    <h3>🛍️ Services & OTP Rates Manager (Add, Change Rate & Delete)</h3>
    <table>
      <thead><tr><th>ID</th><th>Service</th><th>Rate (৳)</th><th>Nums/Click</th><th>Status</th><th>Quick Rate Update</th><th>Actions</th></tr></thead>
      <tbody>{{SERVICE_ROWS}}</tbody>
    </table>
    <div style="margin-top:16px;padding-top:14px;border-top:1px solid #334155;">
      <h4 style="margin:0 0 10px 0;color:#38bdf8;">➕ Quick Add Service</h4>
      <form method="POST" action="/admin/add_service" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;">
        <div>
          <label style="font-size:12px;">Service Name</label>
          <input type="text" name="srv_name" placeholder="FACEBOOK" required style="width:140px;">
        </div>
        <div>
          <label style="font-size:12px;">Icon Emoji</label>
          <input type="text" name="srv_icon" value="☑️" required style="width:70px;">
        </div>
        <div>
          <label style="font-size:12px;">Rate (৳)</label>
          <input type="number" step="0.1" name="srv_rate" value="2.5" required style="width:90px;">
        </div>
        <div>
          <label style="font-size:12px;">Nums/Click</label>
          <input type="number" name="srv_num_cnt" value="1" min="1" max="5" required style="width:90px;">
        </div>
        <button type="submit" class="btn-green" style="height:42px;">➕ Add Service</button>
      </form>
    </div>
  </div>

  <div class="card">
    <h3>👥 Registered Users Directory ( Balance, OTPs, Referrals, Role & Status )</h3>
    <table>
      <thead><tr><th>User ID</th><th>Name & Username</th><th>Balance</th><th>OTPs</th><th>Refs</th><th>Role</th><th>Status</th></tr></thead>
      <tbody>{{USER_ROWS}}</tbody>
    </table>
  </div>

  <div class="card">
    <h3>📩 Recent OTP Logs</h3>
    <table>
      <thead><tr><th>Time</th><th>Service</th><th>Number</th><th>OTP Code</th><th>Full SMS</th><th>User ID</th><th>Reward</th></tr></thead>
      <tbody>{{OTP_ROWS}}</tbody>
    </table>
  </div>
</div>
</body>
</html>
"""


def render_admin_html() -> str:
    st = get_system_stats()
    conn = get_db()
    cnts = conn.execute("""
        SELECT c.id as cid, c.name as cname, c.flag, c.dial_code, s.id as sid, s.name as sname
        FROM countries c JOIN services s ON c.service_id = s.id
        ORDER BY s.id ASC, c.id ASC
    """).fetchall()
    otps = conn.execute("SELECT * FROM otp_logs ORDER BY id DESC LIMIT 12").fetchall()
    users_rows = conn.execute("SELECT * FROM users ORDER BY balance DESC, joined_at DESC LIMIT 50").fetchall()
    conn.close()

    all_adms = get_all_admin_ids()
    adm_badges = [f"<code>{a}</code>" for a in all_adms]
    user_table_rows = []
    for u in users_rows:
        uid = u["user_id"]
        role_str = "👑 Owner" if uid in ADMIN_IDS else ("🛡️ Admin" if uid in all_adms else "👤 User")
        st_str = "<span style='color:#ef4444;font-weight:700;'>🚫 Banned</span>" if u["is_banned"] else "<span class='badge bg-ok'>Active</span>"
        uname = f"@{u['username']}" if u["username"] else "-"
        user_table_rows.append(
            f"<tr><td><code>{uid}</code></td><td><b>{u['first_name']}</b> ({uname})</td>"
            f"<td style='color:#34d399;font-weight:700;'>{u['balance']:.2f} ৳</td>"
            f"<td>{u['total_otps']}</td><td>{u['total_invites']}</td>"
            f"<td>{role_str}</td><td>{st_str}</td></tr>"
        )

    opts = []
    for c in cnts:
        opts.append(f'<option value="{c["sid"]}:{c["cid"]}">{c["sname"]} — {c["flag"]} {c["cname"]} ({c["dial_code"]})</option>')

    otp_rows = []
    for o in otps:
        otp_rows.append(
            f"<tr><td>{o['created_at']}</td><td>{o['country_flag']} {o['service_name']}</td>"
            f"<td><code>{o['phone']}</code></td><td><span class='badge bg-ok'>{o['otp_code']}</span></td>"
            f"<td>{o['full_sms']}</td><td><code>{o['user_id'] or '-'}</code></td><td>+{o['reward']}৳</td></tr>"
        )

    srv_rows = []
    all_srvs = get_all_services()
    for s in all_srvs:
        s_st = "<span class='badge bg-ok'>Active</span>" if s["is_active"] else "<span style='color:#ef4444;font-weight:700;'>Inactive</span>"
        srv_rows.append(
            f"<tr><td><code>#{s['id']}</code></td>"
            f"<td><b>{s['icon']} {s['name']}</b></td>"
            f"<td style='color:#34d399;font-weight:700;font-size:15px;'>{s['otp_rate']:.2f} ৳</td>"
            f"<td>{s['numbers_per_click']}</td>"
            f"<td>{s_st}</td>"
            f"<td>"
            f"<form method='POST' action='/admin/update_service_rate' style='display:inline-flex;gap:6px;'>"
            f"<input type='hidden' name='service_id' value='{s['id']}'>"
            f"<input type='number' step='0.1' name='otp_rate' value='{s['otp_rate']}' style='width:75px;padding:4px 8px;'>"
            f"<button type='submit' class='btn-blue' style='padding:4px 10px;font-size:12px;'>Save Rate</button>"
            f"</form>"
            f"</td>"
            f"<td>"
            f"<form method='POST' action='/admin/delete_service' onsubmit=\"return confirm('Delete {s['name']} permanently?');\" style='display:inline;'>"
            f"<input type='hidden' name='service_id' value='{s['id']}'>"
            f"<button type='submit' style='padding:5px 10px;font-size:12px;background:#ef4444;color:#fff;border:0;border-radius:6px;cursor:pointer;font-weight:600;'>🗑️ Delete</button>"
            f"</form>"
            f"</td></tr>"
        )

    w_en = get_setting("withdrawals_enabled", "0")
    html = WEB_ADMIN_HTML
    replacements = {
        "{{TOTAL_USERS}}": str(st["total_users"]),
        "{{AVAIL_NUMS}}": str(st["avail_nums"]),
        "{{TOTAL_NUMS}}": str(st["total_nums"]),
        "{{TOTAL_OTPS}}": str(st["total_otps"]),
        "{{TOTAL_BAL}}": f"{st['total_user_balance']:.2f}",
        "{{PENDING_W}}": str(st["pending_withdrawals"]),
        "{{SERVICE_ROWS}}": "\n".join(srv_rows) if srv_rows else "<tr><td colspan='7'>No services configured.</td></tr>",
        "{{COUNTRY_OPTIONS}}": "\n".join(opts),
        "{{OTP_GROUP_CHAT_ID}}": get_setting("otp_group_chat_id", ""),
        "{{OTP_GROUP_URL}}": get_setting("otp_group_url", ""),
        "{{CHANNEL_URL}}": get_setting("channel_url", ""),
        "{{SUPPORT_URL}}": get_setting("support_url", ""),
        "{{MIN_PAYOUT}}": get_setting("min_payout", "100.0"),
        "{{REF_COMM}}": get_setting("ref_commission", "0.1"),
        "{{W_OFF}}": "selected" if w_en == "0" else "",
        "{{W_ON}}": "selected" if w_en == "1" else "",
        "{{PANEL_API_URL}}": get_setting("panel_api_url", ""),
        "{{PANEL_API_TOKEN}}": get_setting("panel_api_token", ""),
        "{{API_OFF}}": "selected" if get_setting("panel_api_enabled", "0") == "0" else "",
        "{{API_ON}}": "selected" if get_setting("panel_api_enabled", "0") == "1" else "",
        "{{BOT_DESCRIPTION}}": get_setting("bot_description", ""),
        "{{WELCOME_IMAGE_URL}}": get_setting("welcome_image_url", ""),
        "{{WELCOME_TEXT}}": get_setting("welcome_text", ""),
        "{{ADMIN_LIST_HTML}}": ", ".join(adm_badges),
        "{{USER_ROWS}}": "\n".join(user_table_rows) if user_table_rows else "<tr><td colspan='7'>No users registered yet. Send /start to the bot!</td></tr>",
        "{{OTP_ROWS}}": "\n".join(otp_rows) if otp_rows else "<tr><td colspan='7'>No OTPs received yet. Fire a test OTP above!</td></tr>"
    }
    for k, v in replacements.items():
        html = html.replace(k, v)
    return html


MAIN_EVENT_LOOP: Optional[asyncio.AbstractEventLoop] = None


class AdminAndWebhookHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: Any) -> None:
        return  # Keep console clean

    def _send_json(self, data: Dict[str, Any], status: int = 200) -> None:
        raw = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _send_html(self, html: str, status: int = 200) -> None:
        raw = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _redirect(self, location: str = "/admin") -> None:
        self.send_response(303)
        self.send_header("Location", location)
        self.end_headers()

    def _parse_body(self) -> Dict[str, str]:
        length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(length).decode("utf-8", errors="replace") if length > 0 else ""
        ctype = self.headers.get("Content-Type", "")
        if "application/json" in ctype:
            try:
                return {str(k): str(v) for k, v in json.loads(raw).items() if v is not None}
            except Exception:
                return {}
        parsed = urllib.parse.parse_qs(raw, keep_blank_values=True)
        return {k: v[0] for k, v in parsed.items()}

    def do_GET(self) -> None:
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path
        if path in ("/", "/admin"):
            self._send_html(render_admin_html())
            return
        if path == "/api/otp":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(parsed_url.query).items()}
            phone = str(q.get("phone") or q.get("number") or "").strip()
            sms = str(q.get("sms") or q.get("message") or "").strip()
            code = q.get("code") or q.get("otp")
            service = q.get("service")
            if not phone or not sms:
                self._send_json({"ok": False, "error": "Missing 'phone' or 'sms' parameter"}, 400)
                return
            if MAIN_EVENT_LOOP:
                fut = asyncio.run_coroutine_threadsafe(
                    process_incoming_otp(phone, sms, code, service), MAIN_EVENT_LOOP
                )
                res = fut.result(timeout=15)
            else:
                res = asyncio.run(process_incoming_otp(phone, sms, code, service))
            self._send_json(res)
            return
        self._send_json({"ok": False, "error": "Not Found"}, 404)

    def do_POST(self) -> None:
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path
        form = self._parse_body()

        if path == "/api/otp":
            phone = str(form.get("phone") or form.get("number") or "").strip()
            sms = str(form.get("sms") or form.get("message") or "").strip()
            code = form.get("code") or form.get("otp")
            service = form.get("service")
            if not phone or not sms:
                self._send_json({"ok": False, "error": "Missing 'phone' or 'sms' parameter"}, 400)
                return
            if MAIN_EVENT_LOOP:
                fut = asyncio.run_coroutine_threadsafe(
                    process_incoming_otp(phone, sms, code, service), MAIN_EVENT_LOOP
                )
                res = fut.result(timeout=15)
            else:
                res = asyncio.run(process_incoming_otp(phone, sms, code, service))
            self._send_json(res)
            return

        if path == "/api/add_numbers":
            # API endpoint to bulk add numbers from external software/scripts
            # Payload: {"service_id": 10, "country_id": 1, "numbers": ["+88017...", "+88018..."]}
            # Or with range: {"service_id": 10, "country_id": 1, "start": "+8801700000000", "count": 100}
            sid = form.get("service_id")
            cid = form.get("country_id")
            if not sid or not cid:
                self._send_json({"ok": False, "error": "Missing 'service_id' or 'country_id'"}, 400)
                return
            
            sid = int(sid)
            cid = int(cid)
            numbers_to_add = []
            
            if "start" in form:
                start_raw = str(form.get("start", "")).strip()
                prefix = "+" if start_raw.startswith("+") else ""
                start_digits = start_raw.lstrip("+")
                count = int(form.get("count", 10))
                start_int = int(start_digits)
                pad_len = len(start_digits)
                for i in range(min(count, 5000)):
                    numbers_to_add.append(f"{prefix}{str(start_int + i).zfill(pad_len)}")
            elif "numbers" in form:
                raw_nums = form.get("numbers")
                if isinstance(raw_nums, list):
                    numbers_to_add = [str(x).strip() for x in raw_nums if str(x).strip()]
                elif isinstance(raw_nums, str):
                    numbers_to_add = [x.strip() for x in re.split(r"[\r\n,;\s]+", raw_nums) if x.strip()]

            if not numbers_to_add:
                self._send_json({"ok": False, "error": "No numbers provided in payload"}, 400)
                return

            conn = get_db()
            added = 0
            for num in numbers_to_add:
                ph = ("+" + num) if not num.startswith("+") else num
                conn.execute(
                    "INSERT INTO numbers (service_id, country_id, phone, status) VALUES (?, ?, ?, 'available')",
                    (sid, cid, ph)
                )
                added += 1
            conn.commit()
            conn.close()
            self._send_json({"ok": True, "added": added, "service_id": sid, "country_id": cid})
            return

        if path == "/admin/fire_otp":
            phone = str(form.get("phone", "")).strip()
            otp_code = str(form.get("otp_code", "")).strip() or None
            full_sms = str(form.get("full_sms", "")).strip()
            if phone and full_sms:
                if MAIN_EVENT_LOOP:
                    fut = asyncio.run_coroutine_threadsafe(
                        process_incoming_otp(phone, full_sms, otp_code), MAIN_EVENT_LOOP
                    )
                    fut.result(timeout=15)
                else:
                    asyncio.run(process_incoming_otp(phone, full_sms, otp_code))
            self._redirect("/admin")
            return

        if path == "/admin/upload_numbers":
            sc = str(form.get("service_country", "1:1"))
            sid, cid = [int(x) for x in sc.split(":")]
            raw = str(form.get("numbers", ""))
            phones = [p.strip() for p in re.split(r"[\r\n,; ]+", raw) if len(p.strip()) >= 6]
            conn = get_db()
            for ph in phones:
                if not ph.startswith("+"):
                    ph = "+" + ph
                conn.execute(
                    "INSERT INTO numbers (service_id, country_id, phone, status) VALUES (?, ?, ?, 'available')",
                    (sid, cid, ph)
                )
            conn.commit()
            conn.close()
            self._redirect("/admin")
            return

        if path == "/admin/save_settings":
            for key in ("otp_group_chat_id", "otp_group_url", "channel_url", "support_url", "min_payout", "ref_commission", "withdrawals_enabled", "panel_api_url", "panel_api_token", "panel_api_enabled", "bot_description", "welcome_image_url", "welcome_text"):
                if key in form:
                    set_setting(key, str(form.get(key, "")).strip())
            if "bot_description" in form and MAIN_EVENT_LOOP:
                new_desc = str(form.get("bot_description", "")).strip()
                if new_desc:
                    asyncio.run_coroutine_threadsafe(bot.set_my_description(new_desc), MAIN_EVENT_LOOP)
            self._redirect("/admin")
            return

        if path == "/admin/manage_user":
            uid_str = str(form.get("user_id", "")).strip()
            action = str(form.get("action", "add_bal")).strip()
            amt = float(form.get("amount", 0) or 0)
            if uid_str.isdigit():
                target_uid = int(uid_str)
                conn = get_db()
                # Ensure user row exists even if added before /start
                conn.execute(
                    "INSERT OR IGNORE INTO users (user_id, username, first_name, joined_at) VALUES (?, '', 'User', ?)",
                    (target_uid, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                )
                if action == "add_bal":
                    conn.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amt, target_uid))
                elif action == "sub_bal":
                    conn.execute("UPDATE users SET balance = MAX(0, balance - ?) WHERE user_id = ?", (amt, target_uid))
                elif action == "set_bal":
                    conn.execute("UPDATE users SET balance = ? WHERE user_id = ?", (amt, target_uid))
                elif action == "zero_bal":
                    conn.execute("UPDATE users SET balance = 0 WHERE user_id = ?", (target_uid,))
                elif action == "ban":
                    if target_uid not in ADMIN_IDS:
                        conn.execute("UPDATE users SET is_banned = 1 WHERE user_id = ?", (target_uid,))
                elif action == "unban":
                    conn.execute("UPDATE users SET is_banned = 0 WHERE user_id = ?", (target_uid,))
                conn.commit()
                conn.close()
            self._redirect("/admin")
            return

        if path == "/admin/manage_admin":
            uid_str = str(form.get("admin_user_id", "")).strip()
            role_action = str(form.get("role_action", "add")).strip()
            if uid_str.isdigit():
                target_uid = int(uid_str)
                if role_action == "add":
                    add_admin_db(target_uid, 0)
                else:
                    remove_admin_db(target_uid)
            self._redirect("/admin")
            return

        if path == "/admin/add_service_country":
            s_name = str(form.get("srv_name", "SERVICE")).strip().upper()
            s_icon = str(form.get("srv_icon", "☑️")).strip()
            s_rate = float(form.get("srv_rate", 2.5) or 2.5)
            s_cnt = int(form.get("srv_num_cnt", 1) or 1)
            c_name = str(form.get("cnt_name", "COUNTRY")).strip().upper()
            c_flag = str(form.get("cnt_flag", "🌐")).strip()
            c_code = str(form.get("cnt_code", "+1")).strip()
            if not c_code.startswith("+"):
                c_code = "+" + c_code

            conn = get_db()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO services (name, icon, otp_rate, numbers_per_click, is_active) VALUES (?, ?, ?, ?, 1)",
                (s_name, s_icon, s_rate, s_cnt)
            )
            sid = cur.lastrowid
            cur.execute(
                "INSERT INTO countries (service_id, name, flag, dial_code, is_active) VALUES (?, ?, ?, ?, 1)",
                (sid, c_name, c_flag, c_code)
            )
            conn.commit()
            conn.close()
            self._redirect("/admin")
            return

        if path == "/admin/update_service_rate":
            sid = int(form.get("service_id", 0) or 0)
            new_r = float(form.get("otp_rate", 2.5) or 2.5)
            if sid > 0:
                update_service_rate(sid, new_r)
            self._redirect("/admin")
            return

        if path == "/admin/delete_service":
            sid = int(form.get("service_id", 0) or 0)
            if sid > 0:
                delete_service(sid)
            self._redirect("/admin")
            return

        if path == "/admin/add_service":
            s_name = str(form.get("srv_name", "")).strip().upper()
            s_icon = str(form.get("srv_icon", "☑️")).strip() or "☑️"
            s_rate = float(form.get("srv_rate", 2.5) or 2.5)
            s_num = int(form.get("srv_num_cnt", 1) or 1)
            if s_name:
                add_service(s_name, s_icon, s_rate, s_num)
            self._redirect("/admin")
            return

        self._redirect("/admin")


# ===========================================================================
# 🚀 POLLING LOOP & SERVER RUNNER
# ===========================================================================
async def telegram_polling_loop() -> None:
    tok = os.getenv("BOT_TOKEN", BOT_TOKEN)
    if not tok or tok == "YOUR_BOT_TOKEN_HERE":
        logger.warning("⚠️ BOT_TOKEN is not set yet! Edit BOT_TOKEN in ehr_otp_bot.py or pass BOT_TOKEN env variable.")
        while True:
            await asyncio.sleep(3600)

    me = await bot.call("getMe")
    if not me.get("ok"):
        logger.error(f"❌ Invalid BOT_TOKEN! Telegram responded: {me}")
        return

    bot_user = me["result"]
    bot_uname = bot_user.get("username", "EHR_QUICKINCOME_BOT")
    set_setting("bot_username", bot_uname)
    logger.info(f"✅ Connected to Telegram Bot: @{bot_uname} (ID: {bot_user.get('id')})")

    # Configure Telegram Start / Menu Button & Commands Drawer
    bot_commands = [
        {"command": "start", "description": "🚀 Main Menu / Start"},
        {"command": "getnumber", "description": "➕ Select Service & Get Number"},
        {"command": "balance", "description": "💰 Balance & Withdraw"},
        {"command": "leaderboard", "description": "🏆 Top Performers Leaderboard"},
        {"command": "services", "description": "🛍️ Services & Live OTP Rates"},
        {"command": "referral", "description": "👥 Affiliate Program & Refer"},
        {"command": "support", "description": "🧑‍💻 Help & Support Admins"},
        {"command": "admin", "description": "⚙️ Super Admin Panel"}
    ]
    await bot.set_my_commands(bot_commands)
    await bot.set_chat_menu_button(menu_button={"type": "commands"})

    # Configure Telegram Description (What can this bot do?)
    bot_desc = get_setting("bot_description", "").strip()
    if not bot_desc:
        bot_desc = (
            "⚡ EHR Quick Income এ আপনাকে স্বাগতম!\n\n"
            "আপনার বিশ্বস্ত অটোমেটেড ওটিপি ও ভার্চুয়াল নাম্বার প্ল্যাটফর্ম।\n\n"
            "🛍️ Shopee • Facebook • Instagram • TikTok\n"
            "💳 ইনস্ট্যান্ট বিকাশ, নগদ, রকেটে পেমেন্ট\n"
            "⚡ সম্পূর্ণ অটোমেটেড সিস্টেম"
        )
        set_setting("bot_description", bot_desc)
    try:
        await bot.set_my_description(bot_desc)
        await bot.set_my_short_description("EHR Quick Income - Automated OTP & Virtual Numbers")
        logger.info("✅ Telegram Bot Description & Short Description synced successfully!")
    except Exception as e:
        logger.debug(f"Description sync notice: {e}")

    logger.info("✅ Telegram Start / Menu Button & Commands configured successfully!")

    offset = 0
    while True:
        try:
            res = await bot.call("getUpdates", {
                "offset": offset,
                "timeout": 25,
                "allowed_updates": ["message", "callback_query"]
            })
            if res.get("ok"):
                for upd in res.get("result", []):
                    offset = upd["update_id"] + 1
                    if "message" in upd:
                        asyncio.create_task(handle_message(upd["message"]))
                    elif "callback_query" in upd:
                        asyncio.create_task(handle_callback_query(upd["callback_query"]))
            else:
                await asyncio.sleep(3)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"Polling error: {e}")
            await asyncio.sleep(3)


SEEN_PANEL_OTP_HASHES = set()
IS_INITIAL_PANEL_POLL = True


def _sync_fetch_panel_api(api_url: str, api_token: str) -> Any:
    headers = {"User-Agent": "EHR-OTP-Bot/2.0", "Accept": "application/json"}
    if api_token:
        headers["Authorization"] = f"Bearer {api_token}"
        headers["X-API-Key"] = api_token
    req = urllib.request.Request(api_url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8", errors="ignore"))


async def _fetch_panel_api_async(api_url: str, api_token: str) -> Any:
    headers = {"User-Agent": "EHR-OTP-Bot/2.0", "Accept": "application/json"}
    if api_token:
        headers["Authorization"] = f"Bearer {api_token}"
        headers["X-API-Key"] = api_token
    session = await bot.get_session()
    if session:
        try:
            async with session.get(api_url, headers=headers, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                return await resp.json(content_type=None)
        except Exception as e:
            logger.debug(f"Panel API aiohttp get failed: {e}")
    return await asyncio.to_thread(_sync_fetch_panel_api, api_url, api_token)


async def external_panel_api_poller() -> None:
    """
    If the client enables 'Number Panel API' in Admin Panel (or sets panel_api_url),
    this background worker automatically polls their Number Panel API for new SMS/OTPs!
    Supports common panel JSON formats:
      - [{"phone": "+998...", "sms": "754891 is your code"}, ...]
      - {"data": [{"number": "...", "message": "..."}]}
      - {"messages": [{"to": "...", "text": "..."}]}
    """
    global IS_INITIAL_PANEL_POLL
    while True:
        try:
            enabled = get_setting("panel_api_enabled", "0") == "1"
            api_url = get_setting("panel_api_url", "").strip()
            api_token = get_setting("panel_api_token", "").strip()
            interval = max(3, int(get_setting("panel_poll_interval", "8") or "8"))

            if enabled and api_url.startswith("http"):
                payload = await _fetch_panel_api_async(api_url, api_token)
                items = []
                if isinstance(payload, list):
                    items = payload
                elif isinstance(payload, dict):
                    for k in ("data", "messages", "sms", "result", "rows", "items"):
                        if isinstance(payload.get(k), list):
                            items = payload[k]
                            break
                    if not items and ("phone" in payload or "number" in payload):
                        items = [payload]

                if IS_INITIAL_PANEL_POLL:
                    for item in items:
                        if isinstance(item, dict):
                            phone = str(item.get("phone") or item.get("number") or item.get("to") or item.get("msisdn") or "").strip()
                            sms = str(item.get("sms") or item.get("message") or item.get("text") or item.get("body") or "").strip()
                            if phone and sms:
                                SEEN_PANEL_OTP_HASHES.add(f"{phone}:{sms}")
                    IS_INITIAL_PANEL_POLL = False
                    logger.info(f"✅ Initial panel sync complete. Seeded {len(SEEN_PANEL_OTP_HASHES)} historical records.")
                else:
                    for item in items:
                        if not isinstance(item, dict):
                            continue
                        phone = str(item.get("phone") or item.get("number") or item.get("to") or item.get("msisdn") or "").strip()
                        sms = str(item.get("sms") or item.get("message") or item.get("text") or item.get("body") or "").strip()
                        code = item.get("code") or item.get("otp")
                        service = item.get("service") or item.get("app") or item.get("cli") or item.get("sender")
                        if phone and sms:
                            uniq_key = f"{phone}:{sms}"
                            if uniq_key not in SEEN_PANEL_OTP_HASHES:
                                SEEN_PANEL_OTP_HASHES.add(uniq_key)
                                asyncio.create_task(
                                    process_incoming_otp(
                                        phone,
                                        sms,
                                        str(code) if code else None,
                                        str(service) if service else None
                                    )
                                )
            await asyncio.sleep(interval)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.debug(f"Panel API Poll Error: {e}")
            await asyncio.sleep(8)


async def main() -> None:
    global MAIN_EVENT_LOOP
    MAIN_EVENT_LOOP = asyncio.get_running_loop()

    init_db()
    logger.info("✅ SQLite Database initialized with default Services, Countries & Numbers pool.")

    httpd = ThreadingHTTPServer(("0.0.0.0", WEB_PORT), AdminAndWebhookHandler)
    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()
    logger.info(f"🌐 Web Admin Panel & OTP Webhook API running at: http://localhost:{WEB_PORT}/admin")

    asyncio.create_task(external_panel_api_poller())
    await telegram_polling_loop()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped.")